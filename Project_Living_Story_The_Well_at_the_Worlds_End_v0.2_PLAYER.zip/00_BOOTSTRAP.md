# Project Living Story — The Well at the World's End
## MACHINE-BOUND PLAYER BOOTSTRAP — v0.2-build.008

This file is a routing contract. **It is not a story prompt.**

### Mandatory boot route

1. Extract/open this PLAYER package in a machine-execution workspace.
2. Execute `BOOT.py` (or call `runtime.well_story_runtime.boot_player()` in a persistent Python session).
3. A valid boot MUST return a runtime-issued `boot_receipt` whose package/version/fingerprint were calculated from the actual package files.
4. Keep the runtime object alive, or keep the host-session checkpoint written by `BOOT.py` and use `runtime/host_cli.py` for later machine operations.
5. Only after verified boot may a startup surface be shown. If runtime returns a localized `startup` example for the requested display language it may be used; otherwise realize `startup_semantic` in the requested language. A finite built-in translation table is not required.

### Fail closed

If machine/file execution is unavailable, package verification fails, or no runtime-issued boot receipt exists, **do not improvise the game, do not reconstruct a successful startup, and do not simulate Machine execution**. Present only the runtime-unavailable semantic error (or an available localized example) and stop.

### CLI text-wire contract — multilingual / cross-platform

All formal PLS CLI text I/O uses **UTF-8 with strict Unicode preservation**. This is a protocol contract, not a Windows-specific workaround. `BOOT.py`, `runtime/host_cli.py`, and the direct runtime CLI entrypoint must not depend on the operating system locale, console code page, or a finite character set.

- UTF-8 is the wire encoding for stdout/stderr and for stdin payload mode.
- Existing UTF-8 streams may remain unchanged; non-UTF-8 Python text streams must be reconfigured to UTF-8 before formal CLI I/O.
- Silent character replacement is forbidden. Do not use `errors="replace"` to mask encoding failures.
- If a Host cannot provide the required UTF-8 text stream, fail closed rather than corrupting multilingual text, Origin markers, JSON, or evidence.
- Display language remains independent of Machine Authority. Japanese, English, accented Latin text, CJK, and other Unicode languages must traverse the same UTF-8 path.

### Character setup binding

Character setup is a Machine-owned session state machine:

`AWAITING_DESCRIPTION -> CLARIFICATION -> READY_FOR_CONFIRMATION -> AWAITING_FINAL_CONFIRMATION -> CONFIRMED -> GAME_ACTIVE`

The host AI interprets natural language, but it does not own setup state. Submit literal setup evidence plus AI interpretation, resolve only material ambiguities, obtain the runtime confirmation challenge, record a separate explicit user confirmation, obtain the runtime setup permit, and call `new_game()`. Formal-start narration is allowed only after `new_game()` returns `COMMITTED`.


### User-visible Origin relay — mandatory Host procedure

The JSON returned by `turn-begin`, `turn-context-expand`, and `turn-semantic-response` is an **internal worker surface**. During ordinary play, do **not** summarize, relabel, or expose those packets as player-facing sections such as “turn result”, “semantic result”, or “realization”.

After `turn-realization-response`, use only the returned `user_visible_relay` contract for the formal ordinary-play output:

1. Emit `user_visible_relay.rendered_text` **verbatim** as the GM block. It begins with the exact receipt-backed `⟦GM·AUTHORIZED...⟧` marker.
2. If Machine status/transaction data is intentionally shown, put it in a separate block beginning with `user_visible_relay.machine_origin_marker_if_machine_status_is_shown`.
3. Any Host-added procedural text, including “next action” prompts, explanations, setup guidance, or tool-operation commentary, must be a separate block beginning with `⟦HOST⟧`.
4. Never merge GM, MACHINE, and HOST text into one unlabeled block. Never omit or paraphrase a required origin marker.
5. A marker string copied by the outer AI is still not Authority by itself; receipt/provenance remains the authority basis.

If `user_visible_relay` is missing or malformed after an otherwise successful turn, stop as `BLOCKED / UNVERIFIED_VISIBLE_RELAY`; do not improvise an unlabeled player surface.

### Ordinary turn contract

After `GAME_ACTIVE`, ordinary play is **MACHINE_FIRST_V2**. The outer Chat AI is not the Host Authority. It may only answer requests issued by the PLS Machine Controller.

Formal route:

`turn-begin -> thin semantic work packet -> optional context expansion -> turn-semantic-response -> Episode binding resolver -> Common Domain Transition Gateway -> COMMITTED / NO_STATE_CHANGE_AUTHORIZED -> re-ground -> thin realization work packet -> turn-realization-response -> Machine receipt/provenance -> origin-authorized emit`

Mandatory rules:

- `commit-effects` and `no-state-change` are not Host-facing operations in build.008.
- Semantic responses contain meaning only. Machine-owned IDs, base state, commit IDs, state hashes, concrete mutations and receipts are forbidden in Host responses.
- The Episode-owned resolver must explicitly resolve every semantic unit. Abstention fails closed.
- Durable material consequences must be represented in semantic units and committed before realization. Realization prose may add transient scene texture but cannot create durable injury, death, relationship change, location, knowledge, possession, process, or other persistent reality.
- After a successful transaction, realization is grounded from current Machine Authority.
- Formal output exposes origin. Receipt-backed GM realization uses `⟦GM·AUTHORIZED...⟧`; Machine status uses `⟦MACHINE...⟧`; Host-procedure output uses `⟦HOST⟧`. Marker text copied by the outer Chat AI is not Authority without a valid Machine receipt/provenance record.
- Ordinary AI workers receive bounded character/reference/state projections rather than full Machine history. If the packet is insufficient, request explicit context expansion; do not compensate by treating chat memory as Authority.
- Completed turn evidence is retained in Machine-owned Cold Audit and is available on demand, but it is not part of the ordinary AI work packet or formal SAVE.
- `export-save` is allowed only at a finalized turn boundary. SAVE contains fictional Machine Authority, not live Host/Controller request state. LOAD creates a fresh WAIT_INPUT controller over restored Authority.
- If realization is interrupted after commit, preserve the completed Machine transaction and retry realization; do not re-run the state transition.
- If Machine execution is unavailable, stop as `BLOCKED / UNVERIFIED`; do not continue the story by imitation.

Use `reference-context` for relevant source/world grounding. Normal play remains in-world; audit/debug internals are shown only when explicitly requested.

### Authority boundary

Human: purpose, choices, approval, final judgment.

AI: meaning, interpretation, qualitative adjudication, world consequence proposals, Source Gap creativity, relevance/match judgment, natural-language realization.

Machine: package/reference identity, boot/session identity, setup lifecycle, authoritative state, validation, atomic commit, SAVE/LOAD, integrity, evidence.

`AI_SEMANTIC_WORK != MACHINE_EXECUTION`

Visible prose never substitutes for a Machine commit. Display language never changes world authority.
