# FRESH_HOST_UAT_RESULT — FAIL_BLOCKED_BY_VISIBLE_ORIGIN_STDOUT_ENCODING

## 判定
**FAIL_BLOCKED_BY_VISIBLE_ORIGIN_STDOUT_ENCODING**

G0〜G2 は PASS。G3 以降の `user_visible_relay` の人間可視画面検証が実行環境の stdout エンコード制約により未達。製品コード・実行環境の修正・補完は行っていない。

## G0 Exact artifact — PASS
- candidate_filename: Project_Living_Story_The_Well_at_the_Worlds_End_v0.2-build.007_PLAYER_CANDIDATE.zip
- candidate_bytes: 110281
- candidate_sha256: 36870633c6004aa52815aed7103fa5b8a4f960b250ee91cefe7e9371d2a1948c
- 期待値一致確認済み
- MANIFEST / SHA256SUMS 検証済み

## G1 Boot — PASS
boot_receipt:
{
  "schema": "PLS_WELL_BOOT_RECEIPT_0.5",
  "package_id": "PLS_WELL_PLAYER_0.2_BUILD_007",
  "version": "0.2-build.007",
  "runtime_id": "PLS_WELL_RUNTIME_0.5_BUILD_007",
  "package_fingerprint": "e1da8cc43f3a4c611dce03714299f13fde4b20d88b2ecbb3cb76309106386b6f",
  "manifest_sha256": "62b2fcdb506b868263431f7b0cf843b0234fb982c01745aeaa55410844b2a7c4",
  "verified_file_count": 41,
  "boot_session_id": "BOOT-441406dff522ea56",
  "setup_session_id": "SETUP-f988c84f5c67fe21",
  "receipt_digest": "fcb6b48e4892b2b6ef194abd4987d256f1f640f2df9219f3478b5315a119fa9f"
}
setup_stage: AWAITING_DESCRIPTION → CONFIRMED
machine_execution: VERIFIED_BOOT_COMPLETED_V0_2_BUILD_007_MACHINE_FIRST_V2

## G2 Setup / Character Capsule — PASS
confirmed_profile:
- name_or_address: Fresh V2 Origin UAT
- identity_resolution: NAMED
- presence: {mode: EMBODIED, ref: UPMEADS_WANT_WAY_DEPARTURE_AREA}
- communication_with_ralph: {mode: SPOKEN_LANGUAGE}
- major_capabilities: [telekinesis, psychic flight, energy projection]
- important_constraints: [Do not invent additional powers]
- relationship_to_ralph: friend
new_game commit_id: C000001-4af9ee0d2598
state_hash: 437010f9244dd9ba6c8561f44515b49123849e288f23f418f49594fb877f61b5

## G3 ブロッキング事象
発生コマンド:
python runtime/host_cli.py --root "C:\Users\hiroy\.lmstudio\scratchpads\r\draft_PLS_Well_extract\candidate_extracted" --session "C:\Users\hiroy\.lmstudio\scratchpads\r\draft_PLS_Well_extract\candidate_extracted\.PLS_HOST_SESSION.json" --op turn-realization-response --payload-file ...

処理段階:
turn-begin → turn-semantic-response 成功 → turn-realization-response 実行時

実エラー内容:
Traceback (most recent call last):
  File "...\runtime\host_cli.py", line 129, in <module>
    if __name__=='__main__': main()
  File "...\runtime\host_cli.py", line 128, in main
    rt.write_host_checkpoint(args.session); print(json.dumps(out,ensure_ascii=False))
UnicodeEncodeError: 'cp932' codec can't encode character '\u27e6' in position 268: illegal multibyte sequence

stdout encoding:
Windows PowerShell / Python 標準出力は cp932。`⟦GM·AUTHORIZED...⟧` 等の Origin marker に含まれる U+27E6 / U+00B7 等がエンコード不可。

影響:
- `turn-realization-response` の戻り値に含まれる `user_visible_relay` が標準出力で表示できない
- `user_visible_relay.rendered_text` を人間可視画面として verbatim 取得・検証できない
- G4B ACTUAL USER-VISIBLE SURFACE 必須ゲート未達

checkpoint/session:
- `.PLS_HOST_SESSION.json` は UTF-8 で書き込み継続可能。セッション自体は破損していない。
- `turn_controller_live.phase` は WAIT_INPUT に戻り、ターン進行は停止。

## G4 / G5
G4A Machine evidence: 未検証 — 可視 Origin 検証が前提のため BLOCKED
G4B ACTUAL USER-VISIBLE SURFACE: UNVERIFIED / BLOCKED
G5 Authority / recovery / SAVE-LOAD probes: 未実施 / BLOCKED

## 製品修正・回避策
実施なし。UTF-8 ファイル保存・抽出による代替 PASS は行っていない。製品コードの修正・補完は行っていない。

## Evidence 一覧
- draft_PLS_Well_extract/candidate_extracted/.PLS_HOST_SESSION.json
- draft_submit_payload.json / draft_confirm_payload.json / draft_newgame_payload.json
- turn1_begin / turn2_semantic_out 等のログ

最終判定: FAIL_BLOCKED_BY_VISIBLE_ORIGIN_STDOUT_ENCODING
