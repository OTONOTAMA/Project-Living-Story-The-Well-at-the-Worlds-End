from __future__ import annotations
from pathlib import Path
import argparse, json
from runtime.pls_cli_io import configure_utf8_stdio
from runtime.well_story_runtime import boot_player

ROOT=Path(__file__).resolve().parent

def main():
    configure_utf8_stdio(include_stdin=False)
    ap=argparse.ArgumentParser()
    ap.add_argument('--language',default='ja')
    ap.add_argument('--session-file',default=str(ROOT/'.PLS_HOST_SESSION.json'))
    args=ap.parse_args()
    rt,envelope=boot_player(ROOT,args.language)
    session=rt.write_host_checkpoint(args.session_file)
    out=dict(envelope)
    out['host_session_file']=str(session)
    out['machine_execution']='VERIFIED_BOOT_COMPLETED_V0_2_BUILD_008_MACHINE_FIRST_V2'
    print(json.dumps(out,ensure_ascii=False))

if __name__=='__main__':
    main()
