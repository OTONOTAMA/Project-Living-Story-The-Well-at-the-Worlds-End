from __future__ import annotations

import codecs
import sys
from typing import Any, Dict

CLI_TEXT_IO_SCHEMA = "PLS_CLI_TEXT_IO_V1"
CLI_WIRE_ENCODING = "utf-8"
CLI_ERROR_POLICY = "strict"

class CLITextIOError(RuntimeError):
    pass


def _canonical_encoding_name(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        return codecs.lookup(value).name
    except LookupError:
        return value.strip().lower().replace("_", "-")


def _configure_stream(stream: Any, stream_name: str) -> Dict[str, Any]:
    if stream is None:
        raise CLITextIOError(f"CLI_{stream_name.upper()}_MISSING")
    before = getattr(stream, "encoding", None)
    if _canonical_encoding_name(before) == "utf-8":
        return {
            "stream": stream_name,
            "before": before,
            "after": before,
            "changed": False,
            "errors": getattr(stream, "errors", None),
        }
    reconfigure = getattr(stream, "reconfigure", None)
    if not callable(reconfigure):
        raise CLITextIOError(f"CLI_{stream_name.upper()}_UTF8_RECONFIGURE_UNAVAILABLE")
    reconfigure(encoding=CLI_WIRE_ENCODING, errors=CLI_ERROR_POLICY)
    after = getattr(stream, "encoding", None)
    if _canonical_encoding_name(after) != "utf-8":
        raise CLITextIOError(f"CLI_{stream_name.upper()}_UTF8_RECONFIGURE_FAILED")
    return {
        "stream": stream_name,
        "before": before,
        "after": after,
        "changed": True,
        "errors": getattr(stream, "errors", None),
    }


def configure_utf8_stdio(*, include_stdin: bool = True) -> Dict[str, Any]:
    """Enforce the PLS CLI text-wire contract without locale-dependent fallback.

    The formal CLI protocol is UTF-8 with strict Unicode preservation.  Existing
    UTF-8 streams are left unchanged; non-UTF-8 TextIO streams are reconfigured.
    If the host cannot provide a reconfigurable text stream, fail closed rather
    than silently replacing or transcoding characters.
    """
    result = {
        "schema": CLI_TEXT_IO_SCHEMA,
        "wire_encoding": CLI_WIRE_ENCODING,
        "error_policy": CLI_ERROR_POLICY,
        "locale_dependent": False,
    }
    if include_stdin:
        result["stdin"] = _configure_stream(sys.stdin, "stdin")
    result["stdout"] = _configure_stream(sys.stdout, "stdout")
    result["stderr"] = _configure_stream(sys.stderr, "stderr")
    return result
