from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping
import hashlib, json

ROOT=Path(__file__).resolve().parents[1]

def _canon(v): return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def _digest(v): return hashlib.sha256(_canon(v).encode('utf-8')).hexdigest()
def _load(p): return json.loads(Path(p).read_text(encoding='utf-8'))

NO_STATE_PREDICATES={
    'OBSERVE','ASK','DIALOGUE','SPEAK','REPORT','AUDIT','REFERENCE_QUERY','NO_STATE'
}
CONSTRUCTOR_BY_PREDICATE={
    'MOVE':'WELL.MOVE',
    'TIME_ADVANCE':'WELL.TIME_ADVANCE',
    'ACTOR_CONDITION_ADD':'WELL.ACTOR_CONDITION_ADD',
    'ACTOR_CONDITION_REMOVE':'WELL.ACTOR_CONDITION_REMOVE',
    'ACTOR_ALIVE_SET':'WELL.ACTOR_ALIVE_SET',
    'ACTOR_GOAL_ADD':'WELL.ACTOR_GOAL_ADD',
    'ACTOR_GOAL_REMOVE':'WELL.ACTOR_GOAL_REMOVE',
    'ACTOR_KNOWLEDGE_ADD':'WELL.ACTOR_KNOWLEDGE_ADD',
    'PLAYER_CONDITION_ADD':'WELL.PLAYER_CONDITION_ADD',
    'PLAYER_CONDITION_REMOVE':'WELL.PLAYER_CONDITION_REMOVE',
    'PLAYER_KNOWLEDGE_ADD':'WELL.PLAYER_KNOWLEDGE_ADD',
    'PLAYER_POSSESSION_ADD':'WELL.PLAYER_POSSESSION_ADD',
    'PLAYER_POSSESSION_REMOVE':'WELL.PLAYER_POSSESSION_REMOVE',
    'RELATIONSHIP_SET':'WELL.RELATIONSHIP_SET',
    'WORLD_FACT_ADD':'WELL.WORLD_FACT_ADD',
    'LOCATION_STATE_SET':'WELL.LOCATION_STATE_SET',
    'OBJECT_STATE_SET':'WELL.OBJECT_STATE_SET',
    'PROCESS_START':'WELL.PROCESS_START',
    'PROCESS_UPDATE':'WELL.PROCESS_UPDATE',
    'PROCESS_RESOLVE':'WELL.PROCESS_RESOLVE',
    'UNRESOLVED_ADD':'WELL.UNRESOLVED_ADD',
    'UNRESOLVED_RESOLVE':'WELL.UNRESOLVED_RESOLVE',
}

def binding_resolver(unit: Mapping[str,Any], binding: Mapping[str,Any]):
    payload=unit.get('semantic_payload') or {}
    predicate=str(payload.get('predicate') or '').strip().upper()
    if predicate in NO_STATE_PREDICATES:
        if unit.get('persistence_intent') not in {'NONE','EPHEMERAL'}:
            return {'reject':True,'reason':'NO_STATE_PREDICATE_CANNOT_REQUEST_PERSISTENCE'}
        return {'no_state_change':True}
    cid=CONSTRUCTOR_BY_PREDICATE.get(predicate)
    if cid: return {'constructor_id':cid,'target_ref':payload.get('target_ref') or payload.get('actor_id')}
    return {'reject':True,'reason':'UNSUPPORTED_WELL_SEMANTIC_PREDICATE:'+predicate}

def semantic_validator(unit, binding, constructor):
    p=unit.get('semantic_payload') or {}; pred=str(p.get('predicate') or '').upper()
    if pred=='MOVE':
        movers=p.get('movers'); dest=p.get('destination_ref')
        return isinstance(movers,list) and bool(movers) and all(isinstance(x,str) and x for x in movers) and isinstance(dest,str) and bool(dest.strip())
    if pred=='TIME_ADVANCE': return isinstance(p.get('seconds'),int) and p.get('seconds')>=0
    if pred in {'ACTOR_CONDITION_ADD','ACTOR_CONDITION_REMOVE'}: return isinstance(p.get('actor_id'),str) and bool(p.get('actor_id')) and p.get('condition') is not None
    if pred=='ACTOR_ALIVE_SET': return isinstance(p.get('actor_id'),str) and bool(p.get('actor_id')) and isinstance(p.get('alive'),bool)
    if pred in {'ACTOR_GOAL_ADD','ACTOR_GOAL_REMOVE'}: return isinstance(p.get('actor_id'),str) and bool(p.get('actor_id')) and p.get('goal') is not None
    if pred=='ACTOR_KNOWLEDGE_ADD': return isinstance(p.get('actor_id'),str) and bool(p.get('actor_id')) and p.get('knowledge') is not None and p.get('channel','known') in {'known','beliefs','private'}
    if pred in {'PLAYER_CONDITION_ADD','PLAYER_CONDITION_REMOVE'}: return p.get('condition') is not None
    if pred=='PLAYER_KNOWLEDGE_ADD': return p.get('knowledge') is not None
    if pred in {'PLAYER_POSSESSION_ADD','PLAYER_POSSESSION_REMOVE'}: return p.get('item') is not None
    if pred=='RELATIONSHIP_SET': return all(isinstance(p.get(k),str) and p.get(k) for k in ('a','b','relationship_kind','state'))
    if pred=='WORLD_FACT_ADD': return isinstance(p.get('fact'),Mapping) and bool((p.get('fact') or {}).get('id')) and bool((p.get('fact') or {}).get('statement'))
    if pred=='LOCATION_STATE_SET': return isinstance(p.get('location_id'),str) and isinstance(p.get('state'),Mapping)
    if pred=='OBJECT_STATE_SET': return isinstance(p.get('object_id'),str) and isinstance(p.get('state'),Mapping)
    if pred=='PROCESS_START': return isinstance(p.get('process'),Mapping) and bool((p.get('process') or {}).get('id'))
    if pred=='PROCESS_UPDATE': return isinstance(p.get('process_id'),str) and isinstance(p.get('patch'),Mapping)
    if pred=='PROCESS_RESOLVE': return isinstance(p.get('process_id'),str)
    if pred=='UNRESOLVED_ADD': return isinstance(p.get('item'),Mapping) and bool((p.get('item') or {}).get('id'))
    if pred=='UNRESOLVED_RESOLVE': return isinstance(p.get('id'),str) and p.get('resolution') is not None
    return True

def player_view_projector(authority: Mapping[str,Any]):
    state=authority.get('state') or {}
    player=state.get('player') or {}; profile=player.get('profile') or {}
    rel=[deepcopy(r) for r in state.get('relationships',[]) if 'PLAYER' in (r.get('a'),r.get('b'))]
    actors={}
    player_ref=(profile.get('presence') or {}).get('ref')
    for aid,a in (state.get('actors') or {}).items():
        actor_ref=(a.get('location') or {}).get('ref')
        if player_ref is not None and actor_ref!=player_ref:
            continue
        actors[aid]={
            'alive':a.get('alive'),'location':deepcopy(a.get('location')),
            'conditions':deepcopy(a.get('conditions',[])),'goals':deepcopy(a.get('goals',[])),
            'player_awareness':deepcopy(a.get('player_awareness',{})),
        }
    return {
        'world_time':deepcopy(state.get('world_time')),
        'player':{'presence':deepcopy(profile.get('presence')),'conditions':deepcopy(player.get('conditions',[])),'possessions':deepcopy(player.get('possessions',[])),'knowledge':deepcopy(player.get('knowledge',[]))},
        'actors':actors,'relationships':rel,'active_processes':deepcopy(state.get('active_processes',[])),'unresolved':deepcopy(state.get('unresolved',[])),
    }


def _reference_maps():
    op=_load(ROOT/'episode/reference/OPERATIONAL_WORLD_REFERENCE_PACKAGE.json')
    scenes=_load(ROOT/'episode/reference/SOURCE_SCENE_REFERENCE_PACKAGE.json')
    return ({x.get('actor_id'):x for x in op.get('actor_records',[])},
            {x.get('reference_id'):x for x in op.get('world_records',[])},
            op.get('index',{}),
            {x.get('scene_reference_id'):x for x in scenes.get('records',[])})

def _player_location_ref(state):
    pres=((state.get('player') or {}).get('profile') or {}).get('presence') or {}
    if isinstance(pres,Mapping) and isinstance(pres.get('ref'),str): return pres.get('ref')
    return None

def _world_reference_for_location(state, raw_ref, world_map, index):
    if not isinstance(raw_ref,str): return None
    if raw_ref in world_map: return raw_ref
    rid=(index.get('location_ref_to_reference_id') or {}).get(raw_ref) or (index.get('region_id_to_reference_id') or {}).get(raw_ref)
    if rid in world_map: return rid
    loc=((state.get('world') or {}).get('locations') or {}).get(raw_ref)
    if isinstance(loc,Mapping):
        parent=loc.get('parent_reference_id') or loc.get('operational_reference_id')
        if isinstance(parent,str):
            if parent in world_map:return parent
            rid=(index.get('location_ref_to_reference_id') or {}).get(parent) or (index.get('region_id_to_reference_id') or {}).get(parent)
            if rid in world_map:return rid
    return None

def _compact_actor_fact(aid, state_actor, ref_actor):
    # Reference capsules carry source/canon facts only. Current authoritative
    # actor state is projected separately by semantic/realization context so
    # it is not duplicated into the AI working packet.
    ref_actor=ref_actor or {}
    return {
        'kind':'ACTOR_REFERENCE','actor_id':aid,'name':ref_actor.get('name') or aid,
        'identity_core':deepcopy((ref_actor.get('identity_core') or [])[:6]),
        'behavioral_tendencies':deepcopy((ref_actor.get('behavioral_tendencies') or [])[:6]),
        'knowledge_boundaries':deepcopy((ref_actor.get('knowledge_boundaries') or [])[:2]),
        'ordinary_goals_or_pressures':deepcopy((ref_actor.get('ordinary_goals_or_pressures') or [])[:2]),
    }

def _compact_world_fact(rid, rec):
    ident=rec.get('region_or_place_identity') or {}
    return {'kind':'WORLD_REFERENCE','reference_id':rid,'name':ident.get('name'),'place_kind':ident.get('kind'),
            'landscape':deepcopy((rec.get('landscape_and_physical_conditions') or [])[:5]),
            'ordinary_activity':deepcopy((rec.get('ordinary_activity') or [])[:4]),
            'source_gap_generation_envelope':deepcopy((rec.get('source_gap_generation_envelope') or [])[:4]),
            'unresolved_boundaries':deepcopy((rec.get('unresolved_boundaries') or [])[:2])}

def player_character_capsule_projector(authority: Mapping[str,Any]):
    state=authority.get('state') or {}; player=state.get('player') or {}; p=player.get('profile') or {}
    return {'schema':'PLS_CHARACTER_CAPSULE_V1','identity':p.get('name_or_address'),
            'nature':deepcopy(p.get('nature')),'presence':deepcopy(p.get('presence')),
            'communication_with_ralph':deepcopy(p.get('communication_with_ralph')),
            'major_capabilities':deepcopy(p.get('major_capabilities',[])),
            'important_constraints':deepcopy(p.get('important_constraints',[])),
            'current_conditions':deepcopy(player.get('conditions',[])),
            'relationship_anchor':'friend:Ralph'}

def semantic_context_projector(authority: Mapping[str,Any], raw_user_input, actor_ref, target_refs):
    state=authority.get('state') or {}; actors=state.get('actors') or {}; actor_refs,_,_,_=_reference_maps()
    player_ref=_player_location_ref(state); selected=[]
    requested={x for x in ([actor_ref]+list(target_refs or [])) if isinstance(x,str) and x}
    for aid,a in actors.items():
        loc=(a.get('location') or {}).get('ref')
        if aid in requested or (player_ref is not None and loc==player_ref):
            selected.append({'actor_id':aid,'name':(actor_refs.get(aid) or {}).get('name') or aid,'alive':a.get('alive'),
                             'location':deepcopy(a.get('location')),'conditions':deepcopy(a.get('conditions',[])),
                             'goals':deepcopy((a.get('goals') or [])[:2])})
    relationships=[{k:deepcopy(v) for k,v in r.items() if k!='private'} for r in state.get('relationships',[]) if 'PLAYER' in (r.get('a'),r.get('b'))]
    return {'player_location_ref':player_ref,'elapsed_seconds':(state.get('world_time') or {}).get('elapsed_seconds',0),
            'nearby_or_target_actors':selected,'known_player_relationships':relationships,
            'active_process_ids':[x.get('id') for x in state.get('active_processes',[]) if isinstance(x,Mapping) and x.get('id')],
            'unresolved_ids':[x.get('id') for x in state.get('unresolved',[]) if isinstance(x,Mapping) and x.get('id')]}

def realization_context_projector(authority: Mapping[str,Any], transaction, semantic_units, recent):
    state=authority.get('state') or {}; actors=state.get('actors') or {}; actor_refs,_,_,_=_reference_maps(); involved=set(); concise=[]
    keep=('predicate','actor_id','movers','destination_ref','condition','seconds','a','b','relationship_kind','state')
    for unit in semantic_units or []:
        payload=(unit or {}).get('semantic_payload') or {}; entry={k:deepcopy(payload.get(k)) for k in keep if k in payload};
        if entry: concise.append(entry)
        aid=payload.get('actor_id')
        if isinstance(aid,str): involved.add(aid)
        for x in payload.get('movers',[]) if isinstance(payload.get('movers'),list) else []:
            if x!='PLAYER' and isinstance(x,str): involved.add(x)
        for x in (payload.get('a'),payload.get('b')):
            if isinstance(x,str) and x!='PLAYER': involved.add(x)
    actor_state=[{'actor_id':aid,'name':(actor_refs.get(aid) or {}).get('name') or aid,'alive':actors.get(aid,{}).get('alive'),
                  'location':deepcopy(actors.get(aid,{}).get('location')),'conditions':deepcopy(actors.get(aid,{}).get('conditions',[]))}
                 for aid in sorted(involved) if aid in actors]
    return {'transaction_status':transaction.get('status'),'authorized_semantic_outcomes':concise,
            'player':{'location_ref':_player_location_ref(state),'conditions':deepcopy((state.get('player') or {}).get('conditions',[]))},
            'involved_actor_state':actor_state,
            'boundary':'Describe only Machine-authorized state and reference-supported/ephemeral presentation. Do not create new persistent facts in prose.'}

def reference_fact_provider(query: Mapping[str,Any], authority: Mapping[str,Any]):
    state=authority.get('state') or {}; actors=state.get('actors') or {}; actor_map,world_map,index,scene_map=_reference_maps(); facts=[]
    actor_ids=set(); world_ids=set(); facets=list(query.get('facets') or []) if isinstance(query.get('facets'),list) else []
    mode=str(query.get('mode') or 'DEFAULT').upper()
    for x in [query.get('actor_ref')]+list(query.get('target_refs') or []):
        if isinstance(x,str) and x in actor_map: actor_ids.add(x)
    player_ref=_player_location_ref(state)
    # Default packets get a bounded current-scene grounding.  Expansion packets
    # are delta-only: they return only specifically requested facets so an AI
    # request for one extra fact does not re-inject the entire current scene.
    if mode!='EXPANSION' and player_ref:
        # Current actor state is already present in semantic_context_projector.
        # Reference grounding adds only the current place plus explicitly
        # targeted/involved actor canon facts, avoiding duplicate actor payloads.
        rid=_world_reference_for_location(state,player_ref,world_map,index)
        if rid: world_ids.add(rid)
    for unit in query.get('semantic_units',[]) if isinstance(query.get('semantic_units'),list) else []:
        payload=(unit or {}).get('semantic_payload') or {}
        aid=payload.get('actor_id')
        if isinstance(aid,str) and aid in actor_map: actor_ids.add(aid)
        for x in payload.get('movers',[]) if isinstance(payload.get('movers'),list) else []:
            if x in actor_map: actor_ids.add(x)
        dest=payload.get('destination_ref')
        if isinstance(dest,str):
            rid=_world_reference_for_location(state,dest,world_map,index)
            if rid: world_ids.add(rid)
    for facet in facets:
        if not isinstance(facet,str): continue
        if facet in actor_map: actor_ids.add(facet)
        elif facet.startswith('actor:') and facet.split(':',1)[1] in actor_map: actor_ids.add(facet.split(':',1)[1])
        elif facet.startswith('world:'):
            rid=_world_reference_for_location(state,facet.split(':',1)[1],world_map,index)
            if rid: world_ids.add(rid)
        elif facet.startswith('location:'):
            rid=_world_reference_for_location(state,facet.split(':',1)[1],world_map,index)
            if rid: world_ids.add(rid)
    for aid in sorted(actor_ids): facts.append(_compact_actor_fact(aid,actors.get(aid),actor_map.get(aid)))
    for rid in sorted(world_ids): facts.append(_compact_world_fact(rid,world_map[rid]))
    # Source-scene material is expansion-only and compact; default packets never pull future scenes.
    if mode=='EXPANSION' and any(str(x).lower()=='source_scene_candidates' for x in facets):
        scene_ids=[]
        for rid in world_ids:
            for sid in (world_map.get(rid,{}).get('related_source_scene_references') or []):
                if sid in scene_map and sid not in scene_ids: scene_ids.append(sid)
        for sid in scene_ids[:3]:
            rec=scene_map[sid]; facts.append({'kind':'SOURCE_SCENE_REFERENCE','scene_reference_id':sid,'source_anchor':deepcopy(rec.get('source_anchor')),
                                               'observed_facts':deepcopy((rec.get('observed_facts') or [])[:5]),'usage':'REFERENCE_ONLY'})
    return {'schema':'PLS_REFERENCE_FACT_CAPSULE_V1','facts':facts,'facets':facets,
            'expandable_facets':['source_scene_candidates']+[f'actor:{x}' for x in sorted(actor_map)[:8]],
            'authority':'REFERENCE_ONLY_NOT_MACHINE_STATE'}

class WellAuditStoreAdapter:
    def __init__(self, rt): self.rt=rt
    def append(self, record): self.rt._turn_audit_records.append(deepcopy(dict(record)))
    def find_receipt(self, reference):
        if not isinstance(reference,str) or not reference:return None
        fp=None
        if reference.startswith('R:'): fp=reference[2:].strip().upper()
        else:
            import re as _re
            m=_re.search(r'R:([A-Fa-f0-9]{6,64})',reference)
            if m: fp=m.group(1).upper()
        matches=[]
        for rec in self.rt._turn_audit_records:
            receipt=rec.get('receipt') or ((rec.get('turn') or {}).get('receipt'))
            if not isinstance(receipt,Mapping):continue
            if reference==receipt.get('receipt_id'):return deepcopy(rec)
            if fp and str(receipt.get('fingerprint','')).upper()==fp:matches.append(rec)
        return deepcopy(matches[0]) if len(matches)==1 else None
    def find_turn(self, turn_id):
        xs=[r for r in self.rt._turn_audit_records if r.get('turn_id')==turn_id or (r.get('turn') or {}).get('turn_id')==turn_id]
        return deepcopy(xs[-1]) if xs else None

def no_state_context_projector(proposal, resolved):
    return {'semantic_units':[deepcopy(x['unit']) for x in resolved], 'authority_note':'NO_STATE_CHANGE_AUTHORIZED__CURRENT_MACHINE_AUTHORITY_UNCHANGED'}

class WellMachineRuntimeContext:
    def __init__(self, rt):
        self.rt=rt
        self.episode_binding=_load(ROOT/'episode/data/MACHINE_FIRST_TRANSITION_BINDING.json')
        self.binding_resolver=binding_resolver
        self.semantic_validator=semantic_validator
        self.apply_constructor=self._apply_constructor
        self.validate_state=self._validate_state
        self.common_invariant_validator=self._common_invariants
        self.episode_invariant_validator=self._episode_invariants
        self.player_view_projector=player_view_projector
        self.player_character_capsule_projector=player_character_capsule_projector
        self.semantic_context_projector=semantic_context_projector
        self.realization_context_projector=realization_context_projector
        self.reference_fact_provider=reference_fact_provider
        self.no_state_context_projector=no_state_context_projector
        self.initialization_builder=None
        self.commit_finalizer=None
    @property
    def authority(self):
        if self.rt.state is None: return None
        return {'commit_id':self.rt.current_commit_id,'state_digest':self.rt.current_state_hash,'state':deepcopy(self.rt.state)}
    @authority.setter
    def authority(self, value):
        if value is None: return
        state=deepcopy(value.get('state'))
        if not isinstance(state,dict): raise ValueError('MACHINE_AUTHORITY_STATE_REQUIRED')
        expected=value.get('state_digest')
        actual=_digest(state)
        if expected!=actual: raise ValueError('MACHINE_AUTHORITY_STATE_DIGEST_MISMATCH')
        if self.rt.state is None: raise ValueError('NO_ACTIVE_GAME')
        if actual==self.rt.current_state_hash: return
        self.rt._validate_state(state)
        before=self.rt.current_state_hash
        self.rt.state=state
        self.rt._record_commit('MATERIAL_TURN',before,'Machine-first committed turn',_digest({'common_transition_id':value.get('commit_id'),'state_digest':actual}))
    def _validate_state(self,state):
        try: self.rt._validate_state(deepcopy(state)); return (True,'OK')
        except Exception as e: return (False,f'{type(e).__name__}:{e}')
    def _common_invariants(self,state,ftr):
        return self._validate_state(state)
    def _episode_invariants(self,state,ftr):
        # Fixed player↔Ralph setup bridge remains structurally present unless a committed relationship transition changes state.
        if not any(r.get('a')=='PLAYER' and r.get('b')=='RALPH' and r.get('kind')=='friend' for r in state.get('relationships',[])):
            return (False,'RALPH_FRIEND_ANCHOR_MISSING')
        return (True,'OK')
    def _apply_constructor(self,state,mutation,binding_stub):
        cid=mutation.get('constructor_id'); p=mutation.get('payload') or {}
        pred=str(p.get('predicate') or '').upper()
        effects=[]
        if cid=='WELL.MOVE':
            dest=p.get('destination_ref'); movers=p.get('movers') or []
            generated=p.get('generated_destination')
            if generated is not None:
                if not isinstance(generated,Mapping): raise ValueError('GENERATED_DESTINATION_NOT_OBJECT')
                effects.append({'kind':'LOCATION_STATE_SET','location_id':dest,'state':deepcopy(dict(generated))})
            for mover in movers:
                if mover=='PLAYER': effects.append({'kind':'PLAYER_LOCATION_SET','ref':dest})
                else: effects.append({'kind':'ACTOR_LOCATION_SET','actor_id':mover,'location':{'ref':dest,'certainty':'GAME_ADDED_SESSION'}})
        elif cid=='WELL.TIME_ADVANCE': effects=[{'kind':'TIME_ADVANCE','seconds':p.get('seconds')}]
        elif cid=='WELL.ACTOR_CONDITION_ADD': effects=[{'kind':'ACTOR_CONDITION_ADD','actor_id':p.get('actor_id'),'condition':p.get('condition')}]
        elif cid=='WELL.ACTOR_CONDITION_REMOVE': effects=[{'kind':'ACTOR_CONDITION_REMOVE','actor_id':p.get('actor_id'),'condition':p.get('condition')}]
        elif cid=='WELL.ACTOR_ALIVE_SET': effects=[{'kind':'ACTOR_ALIVE_SET','actor_id':p.get('actor_id'),'alive':p.get('alive')}]
        elif cid=='WELL.ACTOR_GOAL_ADD': effects=[{'kind':'ACTOR_GOAL_ADD','actor_id':p.get('actor_id'),'goal':p.get('goal')}]
        elif cid=='WELL.ACTOR_GOAL_REMOVE': effects=[{'kind':'ACTOR_GOAL_REMOVE','actor_id':p.get('actor_id'),'goal':p.get('goal')}]
        elif cid=='WELL.ACTOR_KNOWLEDGE_ADD': effects=[{'kind':'ACTOR_KNOWLEDGE_ADD','actor_id':p.get('actor_id'),'knowledge':p.get('knowledge'),'channel':p.get('channel','known')}]
        elif cid=='WELL.PLAYER_CONDITION_ADD': effects=[{'kind':'PLAYER_CONDITION_ADD','condition':p.get('condition')}]
        elif cid=='WELL.PLAYER_CONDITION_REMOVE': effects=[{'kind':'PLAYER_CONDITION_REMOVE','condition':p.get('condition')}]
        elif cid=='WELL.PLAYER_KNOWLEDGE_ADD': effects=[{'kind':'PLAYER_KNOWLEDGE_ADD','knowledge':p.get('knowledge')}]
        elif cid=='WELL.PLAYER_POSSESSION_ADD': effects=[{'kind':'PLAYER_POSSESSION_ADD','item':p.get('item')}]
        elif cid=='WELL.PLAYER_POSSESSION_REMOVE': effects=[{'kind':'PLAYER_POSSESSION_REMOVE','item':p.get('item')}]
        elif cid=='WELL.RELATIONSHIP_SET': effects=[{'kind':'RELATIONSHIP_SET','a':p.get('a'),'b':p.get('b'),'relationship_kind':p.get('relationship_kind'),'state':p.get('state'),'basis':p.get('basis','session_causality')}]
        elif cid=='WELL.WORLD_FACT_ADD': effects=[{'kind':'GENERATED_FACT_ADD','fact':p.get('fact')}]
        elif cid=='WELL.LOCATION_STATE_SET': effects=[{'kind':'LOCATION_STATE_SET','location_id':p.get('location_id'),'state':p.get('state')}]
        elif cid=='WELL.OBJECT_STATE_SET': effects=[{'kind':'OBJECT_STATE_SET','object_id':p.get('object_id'),'state':p.get('state')}]
        elif cid=='WELL.PROCESS_START': effects=[{'kind':'PROCESS_START','process':p.get('process')}]
        elif cid=='WELL.PROCESS_UPDATE': effects=[{'kind':'PROCESS_UPDATE','process_id':p.get('process_id'),'patch':p.get('patch')}]
        elif cid=='WELL.PROCESS_RESOLVE': effects=[{'kind':'PROCESS_RESOLVE','process_id':p.get('process_id')}]
        elif cid=='WELL.UNRESOLVED_ADD': effects=[{'kind':'UNRESOLVED_ADD','item':p.get('item')}]
        elif cid=='WELL.UNRESOLVED_RESOLVE': effects=[{'kind':'UNRESOLVED_RESOLVE','id':p.get('id'),'resolution':p.get('resolution')}]
        else: raise ValueError('UNSUPPORTED_CONSTRUCTOR:'+str(cid))
        for effect in effects: self.rt._apply_effect(state,effect)
        return state

def build_runtime_context(rt): return WellMachineRuntimeContext(rt)

def build_audit_store(rt): return WellAuditStoreAdapter(rt)

def export_live_controller(controller):
    return controller.export_live_checkpoint()

def restore_live_controller(rt, payload, controller_cls):
    ctx=build_runtime_context(rt); store=build_audit_store(rt)
    if not payload:
        return controller_cls(ctx,audit_store=store)
    return controller_cls.restore_live_checkpoint(ctx,payload,audit_store=store)
