from __future__ import annotations
from pathlib import Path
import argparse, json, sys
from pls_cli_io import configure_utf8_stdio
from well_story_runtime import restore_host_checkpoint
from well_machine_first_adapter import build_runtime_context, build_audit_store, export_live_controller, restore_live_controller
from common.pls_turn_controller_v2 import PLSTurnControllerV2

OPS=[
 'context','submit-draft','prepare-confirmation','confirm','new-game','status','switch-language',
 'export-save','import-save','reference-context','turn-contract',
 'turn-begin','turn-context-expand','turn-semantic-response','turn-realization-response','turn-status',
 'context-telemetry','turn-evidence','origin-surface','verify-receipt','turn-retry-realization','turn-cancel'
]

def read_payload(args):
    if args.payload_file: return json.loads(Path(args.payload_file).read_text(encoding='utf-8'))
    if args.payload_json: return json.loads(args.payload_json)
    if args.stdin_payload:
        raw=sys.stdin.read(); return json.loads(raw) if raw.strip() else {}
    return {}

def get_controller(rt):
    if rt.state is None: return None
    return restore_live_controller(rt, rt._turn_controller_live, PLSTurnControllerV2)

def new_controller(rt):
    return PLSTurnControllerV2(build_runtime_context(rt), audit_store=build_audit_store(rt))

def persist_controller(rt, controller):
    rt._turn_controller_live=export_live_controller(controller) if controller is not None else None

def gm_user_visible_relay(controller, emission):
    origin=emission.get('origin_surface') or {}
    marker=origin.get('marker')
    if not isinstance(marker,str) or not marker:
        raise RuntimeError('GM_ORIGIN_MARKER_REQUIRED_FOR_VISIBLE_RELAY')
    turn_id=emission.get('turn_id')
    machine_origin=controller.make_origin_surface('MACHINE',turn_id=turn_id)
    text=emission.get('text')
    if not isinstance(text,str):
        raise RuntimeError('GM_EMISSION_TEXT_REQUIRED_FOR_VISIBLE_RELAY')
    return {
        'schema':'PLS_USER_VISIBLE_RELAY_V1',
        'required':True,
        'render_mode':'EXACT_GM_BLOCK',
        'rendered_text':marker+'\n'+text,
        'gm_origin_marker':marker,
        'machine_origin_marker_if_machine_status_is_shown':machine_origin.get('marker'),
        'host_procedure_marker':'⟦HOST⟧',
        'ordinary_worker_packets_player_visible':False,
        'unlabeled_host_additions_forbidden':True,
        'receipt_reference':emission.get('receipt_id'),
        'receipt_scope':'EMISSION_TEXT_FIELD_ONLY__MARKER_DERIVED_FROM_RECEIPT_PROVENANCE'
    }

def thin_turn_status(controller):
    if controller is None: return {'status':'NO_ACTIVE_GAME'}
    raw=controller.turn_status()
    return {
        'schema':'PLS_THIN_TURN_STATUS_V1',
        'control_profile':'MACHINE_FIRST_V2',
        'phase':raw.get('phase'),
        'turn_sequence':raw.get('turn_sequence'),
        'turn_id':(raw.get('current') or {}).get('turn_id') if isinstance(raw.get('current'),dict) else None,
        'last_receipt_id':raw.get('last_receipt_id'),
        'last_recovery_note':raw.get('last_recovery_note'),
        'origin_surface':controller.make_origin_surface('MACHINE',turn_id=(raw.get('current') or {}).get('turn_id') if isinstance(raw.get('current'),dict) else None),
    }

def main():
    configure_utf8_stdio(include_stdin=True)
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',required=True); ap.add_argument('--session',required=True)
    ap.add_argument('--op',required=True,choices=OPS)
    ap.add_argument('--payload-json'); ap.add_argument('--payload-file'); ap.add_argument('--stdin-payload',action='store_true')
    args=ap.parse_args(); rt=restore_host_checkpoint(args.session,args.root); payload=read_payload(args); controller=get_controller(rt)
    if args.op=='context': out=rt.character_setup_context()
    elif args.op=='submit-draft': out=rt.submit_character_draft(payload['raw_user_text'],payload['draft_profile'],payload['field_provenance'],payload['classification'],payload.get('open_material_questions',[]))
    elif args.op=='prepare-confirmation': out=rt.prepare_final_confirmation()
    elif args.op=='confirm': out=rt.accept_final_confirmation(payload['raw_user_text'],payload['interpreted_intent'],payload['challenge_id'],payload.get('divergence_confirmed',False),payload.get('low_agency_confirmed',False))
    elif args.op=='new-game':
        out=rt.new_game(payload['bridge_history'],payload['setup_permit'],payload.get('display_language')); controller=new_controller(rt); persist_controller(rt,controller)
    elif args.op=='status':
        out=rt.status_view(); out['control_profile']='MACHINE_FIRST_V2'; out['turn_control']=thin_turn_status(controller)
        out['origin_surface']=controller.make_origin_surface('MACHINE') if controller else {'schema':'PLS_ORIGIN_SURFACE_V1','origin_class':'HOST','authority_basis':'HOST_PROCEDURE_ONLY','marker':'⟦HOST⟧'}
    elif args.op=='switch-language': out=rt.switch_language(payload['display_language'])
    elif args.op=='export-save':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out_boundary=controller.require_finalized_turn_boundary(); out={'status':'SAVE_EXPORTED','boundary_receipt':out_boundary,'save':rt.export_save()}
    elif args.op=='import-save':
        if controller is not None: controller.require_finalized_turn_boundary()
        out=rt.import_save(payload['save']); controller=new_controller(rt); persist_controller(rt,controller)
    elif args.op=='reference-context': out=rt.reference_context(payload)
    elif args.op=='turn-contract': out=rt.turn_execution_contract()
    elif args.op=='turn-begin':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.begin_turn(payload['raw_user_input'],display_language=payload.get('display_language',rt.display_language),actor_ref=payload.get('actor_ref'),target_refs=payload.get('target_refs')); persist_controller(rt,controller)
    elif args.op=='turn-context-expand':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.request_context_expansion(payload['request_id'],payload['facets'],payload['reason']); persist_controller(rt,controller)
    elif args.op=='turn-semantic-response':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.submit_semantic_response(payload); persist_controller(rt,controller)
    elif args.op=='turn-realization-response':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.submit_realization(payload)
        out['user_visible_relay']=gm_user_visible_relay(controller,out)
        persist_controller(rt,controller)
    elif args.op=='turn-status': out=thin_turn_status(controller)
    elif args.op=='context-telemetry':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.get_context_telemetry()
    elif args.op=='turn-evidence':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.full_turn_evidence(payload['reference'])
    elif args.op=='origin-surface':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.make_origin_surface(payload['origin_class'],turn_id=payload.get('turn_id'),receipt_reference=payload.get('receipt_reference'))
    elif args.op=='verify-receipt':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.verify_receipt(payload['reference'], expected_turn_id=payload.get('expected_turn_id'), output_text=payload.get('text'))
    elif args.op=='turn-retry-realization':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.retry_realization(); persist_controller(rt,controller)
    elif args.op=='turn-cancel':
        if controller is None: raise RuntimeError('NO_ACTIVE_GAME')
        out=controller.cancel_turn(payload.get('reason','HOST_REQUESTED_CANCEL')); persist_controller(rt,controller)
    else: raise RuntimeError('UNKNOWN_OP')
    rt.write_host_checkpoint(args.session); print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__': main()
