#!/usr/bin/env python3
"""Project Living Story Common v0.6 — bounded-context Machine-First V2 controller.

V2 is an opt-in layer over the qualified v0.5 controller. It preserves the
v0.5 authority route and separates:
- live recovery state,
- cold audit evidence,
- thin AI work packets.
"""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence
import importlib.util, json, re, sys


def _load_sibling(module_name: str, filename: str):
    path=Path(__file__).with_name(filename)
    key=f"pls_common_v06_{module_name}"
    if key in sys.modules: return sys.modules[key]
    spec=importlib.util.spec_from_file_location(key,path)
    if spec is None or spec.loader is None: raise ImportError(f"cannot load {filename}")
    module=importlib.util.module_from_spec(spec);sys.modules[key]=module;spec.loader.exec_module(module);return module

v1=_load_sibling('turn_v1','pls_turn_controller.py')
canonical_digest=v1.canonical_digest

PROFILE_V2='MACHINE_FIRST_V2'
SEMANTIC_BUDGET=4096
CHARACTER_BUDGET=2048
REFERENCE_BUDGET=4096
REALIZATION_BUDGET=8192
LIVE_CHECKPOINT_BUDGET=32768


def _compact_bytes(value: Any) -> int:
    return len(json.dumps(value,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode('utf-8'))


class InMemoryAuditStore:
    """Reference audit-store implementation for tests and persistent-host adapters."""
    def __init__(self, records: Optional[Sequence[Mapping[str,Any]]]=None):
        self.records=[deepcopy(dict(x)) for x in (records or [])]
    def append(self, record: Mapping[str,Any]) -> None:
        self.records.append(deepcopy(dict(record)))
    def find_receipt(self, reference: str) -> Optional[Dict[str,Any]]:
        if not isinstance(reference,str) or not reference: return None
        fingerprint=None
        if reference.startswith('R:'): fingerprint=reference[2:].strip().upper()
        else:
            m=re.search(r'R:([A-Fa-f0-9]{6,64})',reference)
            if m: fingerprint=m.group(1).upper()
        matches=[]
        for rec in self.records:
            receipt=rec.get('receipt') or ((rec.get('turn') or {}).get('receipt'))
            if not isinstance(receipt,Mapping): continue
            if reference==receipt.get('receipt_id'): return deepcopy(dict(rec))
            if fingerprint and str(receipt.get('fingerprint','')).upper()==fingerprint: matches.append(rec)
        return deepcopy(dict(matches[0])) if len(matches)==1 else None
    def find_turn(self, turn_id: str) -> Optional[Dict[str,Any]]:
        matches=[r for r in self.records if (r.get('turn_id') or (r.get('turn') or {}).get('turn_id'))==turn_id]
        return deepcopy(dict(matches[-1])) if matches else None


class PLSTurnControllerV2(v1.PLSTurnController):
    """MACHINE_FIRST_V2 controller with thin worker surfaces and cold audit."""
    def __init__(self, runtime_context: Any, *, session_id: Optional[str]=None,
                 audit_store: Any=None, presentation_contract: Optional[Mapping[str,Any]]=None):
        super().__init__(runtime_context,session_id=session_id,semantic_context_provider=None,presentation_contract=presentation_contract)
        required=['player_character_capsule_projector','semantic_context_projector','realization_context_projector','reference_fact_provider']
        missing=[name for name in required if getattr(runtime_context,name,None) is None]
        if missing: raise v1.TurnControlError('MACHINE_FIRST_V2 missing Episode context projector(s): '+','.join(missing))
        if audit_store is None or not callable(getattr(audit_store,'append',None)) or not callable(getattr(audit_store,'find_receipt',None)):
            raise v1.TurnControlError('MACHINE_FIRST_V2 requires a Machine-owned audit_store with append/find_receipt')
        self.control_profile=PROFILE_V2
        self.audit_store=audit_store
        self._recent_authorized_events=[]
        self._last_context_telemetry={}

    def _call_mapping(self, name: str, *args) -> Dict[str,Any]:
        fn=getattr(self.runtime_context,name,None)
        if fn is None: raise v1.TurnControlError(f'{name} is required')
        out=fn(*deepcopy(args))
        if out is None: return {}
        if not isinstance(out,Mapping): raise v1.TurnControlError(f'{name} must return a mapping')
        return deepcopy(dict(out))

    def _character_capsule(self, authority: Mapping[str,Any]) -> Dict[str,Any]:
        cap=self._call_mapping('player_character_capsule_projector',authority)
        if 'schema' not in cap: cap={'schema':'PLS_CHARACTER_CAPSULE_V1',**cap}
        return cap

    def _reference_capsule(self, query: Mapping[str,Any], authority: Mapping[str,Any]) -> Dict[str,Any]:
        before=(authority.get('commit_id'),authority.get('state_digest'))
        cap=self._call_mapping('reference_fact_provider',query,authority)
        after_auth=self._authority_snapshot()
        if before!=(after_auth.get('commit_id'),after_auth.get('state_digest')):
            raise v1.TurnControlError('reference_fact_provider mutated Machine Authority')
        if 'schema' not in cap: cap={'schema':'PLS_REFERENCE_FACT_CAPSULE_V1',**cap}
        return cap

    def begin_turn(self, raw_user_input: str, *, display_language: str='und', actor_ref: Optional[str]=None,
                   target_refs: Optional[Sequence[str]]=None) -> Dict[str,Any]:
        full=super().begin_turn(raw_user_input,display_language=display_language,actor_ref=actor_ref,target_refs=target_refs)
        current=self._require_current();authority=self._authority_snapshot()
        char=self._character_capsule(authority)
        semantic_context=self._call_mapping('semantic_context_projector',authority,raw_user_input,actor_ref,list(target_refs or []))
        ref=self._reference_capsule({'phase':'SEMANTIC','mode':'DEFAULT','raw_user_input':raw_user_input,'actor_ref':actor_ref,'target_refs':list(target_refs or [])},authority)
        packet={
            'schema':'PLS_SEMANTIC_WORK_PACKET_V1','control_profile':PROFILE_V2,
            'turn_id':current['turn_id'],'request_id':full['request_id'],'raw_user_input':raw_user_input,
            'display_language':display_language or 'und','character_capsule':char,
            'semantic_context':semantic_context,'reference_capsule':ref,
            'recent_authorized_events':deepcopy(self._recent_authorized_events),
            'response_contract':{'id':'PLS_HOST_SEMANTIC_RESPONSE_v1','allowed_top_level':['request_id','semantic_units','actor_ref','target_refs']},
        }
        current['semantic_work_packet']=deepcopy(packet)
        current['context_expansions']=[]
        current['context_telemetry']={
            'character_capsule_bytes':_compact_bytes(char),
            'reference_capsule_bytes':_compact_bytes(ref),
            'semantic_work_packet_bytes':_compact_bytes(packet),
            'semantic_budget_warning':_compact_bytes(packet)>SEMANTIC_BUDGET,
            'character_budget_warning':_compact_bytes(char)>CHARACTER_BUDGET,
            'reference_budget_warning':_compact_bytes(ref)>REFERENCE_BUDGET,
            'reference_expansion_count':0,
        }
        self._last_context_telemetry=deepcopy(current['context_telemetry'])
        return packet

    def request_context_expansion(self, request_id: str, facets: Sequence[str], reason: str) -> Dict[str,Any]:
        if self._phase not in {'SEMANTIC_REQUEST_ISSUED','REALIZATION_REQUEST_ISSUED'}: raise v1.TurnPhaseError('context expansion allowed only for an active AI request')
        current=self._require_current()
        active=(current.get('semantic_request') if self._phase=='SEMANTIC_REQUEST_ISSUED' else current.get('realization_request')) or {}
        if request_id!=active.get('request_id'): raise v1.StaleTurnError('context expansion request_id does not match active Machine request')
        if not isinstance(facets,Sequence) or isinstance(facets,(str,bytes)) or not all(isinstance(x,str) and x for x in facets): raise v1.HostResponseError('facets must be a non-empty string sequence')
        if not isinstance(reason,str) or not reason.strip(): raise v1.HostResponseError('context expansion reason is required')
        authority=self._authority_snapshot()
        cap=self._reference_capsule({'phase':'SEMANTIC' if self._phase=='SEMANTIC_REQUEST_ISSUED' else 'REALIZATION','mode':'EXPANSION','facets':list(dict.fromkeys(facets)),'reason':reason,'turn_id':current['turn_id']},authority)
        current.setdefault('context_expansions',[]).append(deepcopy(cap))
        tel=current.setdefault('context_telemetry',{})
        tel['reference_expansion_count']=int(tel.get('reference_expansion_count') or 0)+1
        tel.setdefault('reference_expansion_reasons',[]).append(str(reason))
        tel.setdefault('reference_expansion_bytes',[]).append(_compact_bytes(cap))
        self._last_context_telemetry=deepcopy(tel)
        return cap

    def _realization_work_packet(self) -> Dict[str,Any]:
        current=self._require_current();authority=self._authority_snapshot();transaction=current.get('transaction_result') or {}
        proposal=current.get('machine_semantic_proposal') or {}
        char=self._character_capsule(authority)
        ref=self._reference_capsule({'phase':'REALIZATION','mode':'DEFAULT','turn_id':current['turn_id'],'semantic_units':deepcopy(proposal.get('semantic_units') or [])},authority)
        authorized=self._call_mapping('realization_context_projector',authority,transaction,deepcopy(proposal.get('semantic_units') or []),deepcopy(self._recent_authorized_events))
        packet={
            'schema':'PLS_REALIZATION_WORK_PACKET_V1','control_profile':PROFILE_V2,
            'turn_id':current['turn_id'],'request_id':current['realization_request']['request_id'],
            'transaction_status':transaction.get('status'),'display_language':current['display_language'],
            'character_capsule':char,'authorized_context':authorized,'reference_capsule':ref,
            'recent_authorized_events':deepcopy(self._recent_authorized_events),
            'presentation_contract':deepcopy(self.presentation_contract),
            'response_contract':{'id':'PLS_HOST_REALIZATION_RESPONSE_v1','allowed_top_level':['request_id','text']},
        }
        current['realization_work_packet']=deepcopy(packet)
        tel=current.setdefault('context_telemetry',{})
        tel['realization_character_capsule_bytes']=_compact_bytes(char)
        tel['realization_reference_capsule_bytes']=_compact_bytes(ref)
        tel['realization_work_packet_bytes']=_compact_bytes(packet)
        tel['realization_budget_warning']=_compact_bytes(packet)>REALIZATION_BUDGET
        self._last_context_telemetry=deepcopy(tel)
        return packet

    def submit_semantic_response(self, response: Mapping[str,Any]) -> Dict[str,Any]:
        full=super().submit_semantic_response(response)
        if full.get('status')=='BLOCKED':
            return {'schema':'PLS_MACHINE_STATUS_SURFACE_V1','origin_class':'MACHINE','status':'BLOCKED','turn_id':full.get('turn_id'),'reason':(full.get('transaction_result') or {}).get('status')}
        return self._realization_work_packet()

    def retry_realization(self) -> Dict[str,Any]:
        super().retry_realization()
        return self._realization_work_packet()

    def _recent_event_from_archive(self, archived: Mapping[str,Any]) -> Dict[str,Any]:
        proposal=archived.get('machine_semantic_proposal') or {};transaction=archived.get('transaction_result') or {};arc=archived.get('authorized_realization_context') or {}
        return {
            'turn_id':archived.get('turn_id'),'transaction_status':transaction.get('status'),
            'semantic_units':deepcopy(proposal.get('semantic_units') or []),
            'player_visible_delta':deepcopy(arc.get('player_visible_delta') or {}),
        }

    def _append_audit_from_archived(self, archived: Mapping[str,Any], final_phase: str) -> None:
        receipt=deepcopy(archived.get('receipt') or {})
        provenance=deepcopy(archived.get('provenance') or {})
        record={
            'schema':'PLS_COLD_AUDIT_RECORD_V1','session_id':self.session_id,'turn_id':archived.get('turn_id'),
            'final_phase':final_phase,'turn':deepcopy(dict(archived)),'receipt':receipt,'provenance':provenance,
            'context_telemetry':deepcopy(archived.get('context_telemetry') or {}),
        }
        record['audit_digest']=canonical_digest({k:v for k,v in record.items() if k!='audit_digest'})
        self.audit_store.append(record)

    def _prune_live_after_finalize(self, receipt_id: Optional[str]) -> None:
        if receipt_id:
            r=self._receipts.get(receipt_id);p=self._provenance.get(receipt_id)
            self._receipts={receipt_id:deepcopy(r)} if r else {}
            self._provenance={receipt_id:deepcopy(p)} if p else {}
        else:
            self._receipts={};self._provenance={}
        self._permits={k:deepcopy(v) for k,v in self._permits.items() if v.get('status')=='ISSUED'}
        self._archived_turns=[]

    def submit_realization(self, response: Mapping[str,Any]) -> Dict[str,Any]:
        full=super().submit_realization(response)
        if not self._archived_turns: raise v1.TurnControlError('V2 expected finalized turn archive from V1 authority controller')
        archived=deepcopy(self._archived_turns[-1])
        fp=full['receipt_fingerprint'];gm_marker=f"⟦GM·AUTHORIZED·{full['turn_id']}·R:{fp}⟧"
        rid=full['receipt_id']
        if rid in self._provenance:
            self._provenance[rid]['marker']=gm_marker
            self._provenance[rid]['origin_class']='GM'
            self._provenance[rid]['origin_authorization']='EMISSION_AUTHORIZED'
        archived['provenance']=deepcopy(self._provenance.get(rid) or archived.get('provenance') or {})
        archived['context_telemetry']=deepcopy(archived.get('context_telemetry') or self._last_context_telemetry)
        self._append_audit_from_archived(archived,'EMISSION_AUTHORIZED')
        event=self._recent_event_from_archive(archived)
        self._recent_authorized_events=(self._recent_authorized_events+[event])[-4:]
        self._prune_live_after_finalize(rid)
        origin={'schema':'PLS_ORIGIN_SURFACE_V1','origin_class':'GM','authority_basis':'RECEIPT_BACKED_EMISSION','turn_id':full['turn_id'],'receipt_fingerprint':fp,'marker':gm_marker}
        return {'schema':'PLS_GM_EMISSION_SURFACE_V1','status':'EMISSION_AUTHORIZED','origin_surface':origin,'turn_id':full['turn_id'],'receipt_id':rid,'receipt_fingerprint':fp,'text':full['text']}

    def cancel_turn(self, reason: str='HOST_REQUESTED_CANCEL') -> Dict[str,Any]:
        out=super().cancel_turn(reason)
        if self._archived_turns:
            archived=deepcopy(self._archived_turns[-1]);self._append_audit_from_archived(archived,'CANCELLED')
        self._prune_live_after_finalize(None)
        return out

    def _audit_evidence(self, reference: str) -> Optional[Dict[str,Any]]:
        rec=self.audit_store.find_receipt(reference)
        return deepcopy(dict(rec)) if isinstance(rec,Mapping) else None

    def verify_receipt(self, reference: str, *, expected_turn_id: Optional[str]=None, output_text: Optional[str]=None) -> Dict[str,Any]:
        if not isinstance(reference,str) or not reference: return {'valid':False,'reason':'INVALID_REFERENCE'}
        receipt=self._find_receipt(reference);provenance=None
        if receipt is not None: provenance=self._provenance.get(receipt.get('receipt_id'))
        if receipt is None or provenance is None:
            rec=self._audit_evidence(reference)
            if rec:
                receipt=deepcopy(rec.get('receipt') or ((rec.get('turn') or {}).get('receipt')) or {})
                provenance=deepcopy(rec.get('provenance') or ((rec.get('turn') or {}).get('provenance')) or {})
        if not receipt: return {'valid':False,'reason':'RECEIPT_NOT_FOUND'}
        core={k:deepcopy(v) for k,v in receipt.items() if k not in {'receipt_id','fingerprint'}}
        expected_fp=canonical_digest(core).split(':',1)[-1][:12].upper()
        if expected_fp!=receipt.get('fingerprint'): return {'valid':False,'reason':'RECEIPT_FINGERPRINT_MISMATCH'}
        if not provenance or provenance.get('receipt_fingerprint')!=receipt.get('fingerprint'): return {'valid':False,'reason':'PROVENANCE_MISSING_OR_MISMATCH'}
        if expected_turn_id is not None and receipt.get('turn_id')!=expected_turn_id: return {'valid':False,'reason':'TURN_MISMATCH'}
        if output_text is not None and canonical_digest({'text':output_text})!=receipt.get('output_digest'): return {'valid':False,'reason':'OUTPUT_DIGEST_MISMATCH'}
        return {'valid':True,'receipt':deepcopy(receipt),'provenance':deepcopy(provenance)}

    def make_origin_surface(self, origin_class: str, *, turn_id: Optional[str]=None, receipt_reference: Optional[str]=None) -> Dict[str,Any]:
        if origin_class not in {'GM','MACHINE','HOST'}: raise v1.HostResponseError('origin_class must be GM/MACHINE/HOST')
        if origin_class=='GM':
            verdict=self.verify_receipt(receipt_reference or '',expected_turn_id=turn_id)
            if not verdict.get('valid'): raise v1.TurnControlError('GM formal origin requires a valid Machine receipt')
            r=verdict['receipt'];fp=r['fingerprint'];tid=r['turn_id']
            return {'schema':'PLS_ORIGIN_SURFACE_V1','origin_class':'GM','authority_basis':'RECEIPT_BACKED_EMISSION','turn_id':tid,'receipt_fingerprint':fp,'marker':f'⟦GM·AUTHORIZED·{tid}·R:{fp}⟧'}
        if origin_class=='MACHINE':
            auth=self._authority_snapshot(allow_none=True) or {}
            tid=turn_id or (self._current or {}).get('turn_id')
            body='⟦MACHINE'+(f'·{tid}' if tid else '')+(f"·{auth.get('commit_id')}" if auth.get('commit_id') else '')+'⟧'
            return {'schema':'PLS_ORIGIN_SURFACE_V1','origin_class':'MACHINE','authority_basis':'MACHINE_STATUS','turn_id':tid,'marker':body}
        return {'schema':'PLS_ORIGIN_SURFACE_V1','origin_class':'HOST','authority_basis':'HOST_PROCEDURE_ONLY','turn_id':turn_id,'marker':'⟦HOST⟧'}

    def get_context_telemetry(self) -> Dict[str,Any]:
        return {'schema':'PLS_CONTEXT_TELEMETRY_V1','current':deepcopy((self._current or {}).get('context_telemetry') or self._last_context_telemetry),'live_checkpoint_bytes':_compact_bytes(self.export_live_checkpoint())}

    def full_turn_evidence(self, reference: str) -> Dict[str,Any]:
        rec=self._audit_evidence(reference)
        if rec is None and callable(getattr(self.audit_store,'find_turn',None)):
            rec=self.audit_store.find_turn(reference)
        if rec is None: return {'status':'NOT_FOUND'}
        return {'status':'FOUND','record':deepcopy(rec)}

    def export_live_checkpoint(self) -> Dict[str,Any]:
        active={k:deepcopy(v) for k,v in self._permits.items() if v.get('status')=='ISSUED'}
        latest=None
        if self._last_receipt_id and self._last_receipt_id in self._receipts:
            latest={'receipt':deepcopy(self._receipts[self._last_receipt_id]),'provenance':deepcopy(self._provenance.get(self._last_receipt_id))}
        return {
            'schema':'PLS_LIVE_CONTROLLER_METADATA_V2','control_profile':PROFILE_V2,'framework_source_sha256':v1.FRAMEWORK_SOURCE_SHA256,
            'session_id':self.session_id,'turn_sequence':self._turn_sequence,'phase':self._phase,
            'last_receipt_id':self._last_receipt_id,'latest_evidence_cache':latest,'pending_turn':deepcopy(self._current),
            'active_permits':active,'recent_authorized_events':deepcopy(self._recent_authorized_events),'last_recovery_note':self._last_recovery_note,
        }

    @classmethod
    def restore_live_checkpoint(cls, runtime_context: Any, metadata: Mapping[str,Any], *, audit_store: Any, presentation_contract: Optional[Mapping[str,Any]]=None) -> 'PLSTurnControllerV2':
        if not isinstance(metadata,Mapping) or metadata.get('schema')!='PLS_LIVE_CONTROLLER_METADATA_V2': raise v1.TurnControlError('invalid V2 live checkpoint')
        c=cls(runtime_context,session_id=str(metadata.get('session_id') or ''),audit_store=audit_store,presentation_contract=presentation_contract)
        c._turn_sequence=int(metadata.get('turn_sequence') or 0);c._phase=str(metadata.get('phase') or 'WAIT_INPUT');c._last_receipt_id=metadata.get('last_receipt_id');c._last_recovery_note=metadata.get('last_recovery_note')
        c._recent_authorized_events=deepcopy(list(metadata.get('recent_authorized_events') or []))[-4:]
        c._permits=deepcopy(dict(metadata.get('active_permits') or {}))
        cache=metadata.get('latest_evidence_cache') or {}
        if isinstance(cache,Mapping) and isinstance(cache.get('receipt'),Mapping):
            r=deepcopy(dict(cache['receipt']));c._receipts={r['receipt_id']:r};p=cache.get('provenance');c._provenance={r['receipt_id']:deepcopy(dict(p))} if isinstance(p,Mapping) else {}
            if not c.verify_receipt(r['receipt_id']).get('valid'): raise v1.TurnControlError('stored latest evidence failed Machine verification during restore')
        pending=metadata.get('pending_turn');prior_phase=c._phase
        if isinstance(pending,Mapping):
            c._current=deepcopy(dict(pending));transaction=c._current.get('transaction_result') or {};arc=c._current.get('authorized_realization_context') or {}
            # A completed authoritative transaction survives process boundaries and
            # reissues only the realization request; it is never recommitted.
            if transaction.get('status') in v1.SUCCESS_TRANSACTION_STATUSES and arc:
                authority=c._authority_snapshot()
                if authority.get('commit_id')!=arc.get('commit_id') or authority.get('state_digest')!=arc.get('state_digest'): raise v1.TurnControlError('restored Domain authority does not match completed pending transaction')
                c._last_context_telemetry=deepcopy(c._current.get('context_telemetry') or {})
                c._phase='TRANSACTION_RESOLVED';c._last_recovery_note='COMPLETED_TRANSACTION_PRESERVED__REALIZATION_REISSUED';c.retry_realization();return c

            # build.002: process-per-operation Hosts must be able to continue an
            # issued semantic request without weakening Machine Authority.  The
            # base authority and the exact still-issued semantic permit are both
            # required; stale or incomplete checkpoints fail closed.
            if prior_phase=='SEMANTIC_REQUEST_ISSUED':
                authority=c._authority_snapshot()
                base_commit=c._current.get('base_commit_id');base_state=c._current.get('base_state_digest')
                if authority.get('commit_id')!=base_commit or authority.get('state_digest')!=base_state:
                    raise v1.StaleTurnError('restored semantic request base no longer matches Machine Authority')
                req=c._current.get('semantic_request') or {}
                permit_id=req.get('permit_id');permit=c._permits.get(permit_id)
                intact=(isinstance(permit,Mapping) and permit.get('status')=='ISSUED' and permit.get('stage')=='SEMANTIC_RESPONSE'
                        and permit.get('turn_id')==c._current.get('turn_id') and permit.get('request_id')==req.get('request_id')
                        and permit.get('base_commit_id')==base_commit and permit.get('base_state_digest')==base_state
                        and permit.get('input_digest')==c._current.get('source_input_digest'))
                if not intact:
                    raise v1.StaleTurnError('restored semantic request permit is missing, stale, or inconsistent')
                c._last_context_telemetry=deepcopy(c._current.get('context_telemetry') or {})
                c._phase='SEMANTIC_REQUEST_ISSUED';c._last_recovery_note='SEMANTIC_REQUEST_PRESERVED_ACROSS_PROCESS_BOUNDARY';return c

            # BLOCKED contains no successful transaction and is safe to retain
            # only while its original base is still current, so the Host can
            # explicitly cancel it rather than losing audit continuity.
            if prior_phase=='BLOCKED':
                authority=c._authority_snapshot()
                if authority.get('commit_id')!=c._current.get('base_commit_id') or authority.get('state_digest')!=c._current.get('base_state_digest'):
                    raise v1.StaleTurnError('restored blocked turn base no longer matches Machine Authority')
                c._last_context_telemetry=deepcopy(c._current.get('context_telemetry') or {})
                c._phase='BLOCKED';c._last_recovery_note='BLOCKED_TURN_PRESERVED_FOR_EXPLICIT_CANCEL';return c

        if prior_phase!='WAIT_INPUT' or pending:
            c._last_recovery_note='STALE_PRETRANSACTION_STAGE_INVALIDATED_ON_RESTORE'
        c._phase='WAIT_INPUT';c._current=None;c._permits={}
        return c
