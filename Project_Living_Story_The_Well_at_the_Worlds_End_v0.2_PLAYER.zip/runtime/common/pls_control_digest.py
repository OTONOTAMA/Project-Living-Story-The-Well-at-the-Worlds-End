"""PLS control digest profile.

Semantics are copied from ChatGPT Bundle Framework v0.20
runtime/control/digest.py and source-bound to exact Framework v0.20 STABLE:
SHA-256 9de31d5ff04a2336e822cb5ab712575f11a17b13cd0c33ddd09b4ef07ff1084a.

This local copy avoids a runtime dependency on the full Framework while retaining
its canonical JSON SHA-256 identity semantics for PLS control records.
"""
from __future__ import annotations
import hashlib
import json
import math
from typing import Any

DIGEST_PROFILE_ID = "CBF_CANONICAL_JSON_SHA256_V1"
FRAMEWORK_SOURCE_SHA256 = "9de31d5ff04a2336e822cb5ab712575f11a17b13cd0c33ddd09b4ef07ff1084a"
FIXED_MIN_DECIMAL_EXPONENT = -4
FIXED_MAX_DECIMAL_EXPONENT_EXCLUSIVE = 16


def _shortest_components(value: float) -> tuple[str, int]:
    token = repr(abs(value)).lower()
    if "e" in token:
        mantissa, exponent_text = token.split("e", 1)
        exponent = int(exponent_text)
    else:
        mantissa, exponent = token, 0
    if "." in mantissa:
        integer_part, fractional_part = mantissa.split(".", 1)
    else:
        integer_part, fractional_part = mantissa, ""
    digits = integer_part + fractional_part
    decimal_index = len(integer_part) + exponent
    leading = len(digits) - len(digits.lstrip("0"))
    if leading:
        digits = digits[leading:]
        decimal_index -= leading
    digits = digits.rstrip("0") or "0"
    return digits, decimal_index


def _render_binary64(value: float) -> str:
    sign = "-" if value < 0 else ""
    digits, decimal_index = _shortest_components(value)
    k = decimal_index - 1
    if FIXED_MIN_DECIMAL_EXPONENT <= k < FIXED_MAX_DECIMAL_EXPONENT_EXCLUSIVE:
        if decimal_index <= 0:
            body = "0." + ("0" * (-decimal_index)) + digits
        elif decimal_index >= len(digits):
            body = digits + ("0" * (decimal_index - len(digits)))
        else:
            body = digits[:decimal_index] + "." + digits[decimal_index:]
        return sign + body
    mantissa = digits[0] if len(digits) == 1 else digits[0] + "." + digits[1:]
    scientific = f"{sign}{mantissa}e{k}"
    if value.is_integer():
        integer_candidate = str(int(value))
        try:
            if float(integer_candidate) == value and len(integer_candidate) < len(scientific):
                return integer_candidate
        except OverflowError:
            pass
    return scientific


def _number_text(value: int | float) -> str:
    if isinstance(value, bool):
        raise TypeError("boolean is not a numeric value in canonical number serialization")
    if isinstance(value, int):
        return str(value)
    if not isinstance(value, float):
        raise TypeError("unsupported numeric type")
    if not math.isfinite(value):
        raise ValueError("non-finite numbers are not permitted by canonical digest profile")
    if value == 0.0:
        return "0"
    return _render_binary64(value)


def _json_string(value: str) -> str:
    if any(0xD800 <= ord(ch) <= 0xDFFF for ch in value):
        raise ValueError("lone surrogate code points are not permitted by canonical digest profile")
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _serialize_text(value: Any) -> str:
    if value is None: return "null"
    if value is True: return "true"
    if value is False: return "false"
    if isinstance(value, int) and not isinstance(value, bool): return _number_text(value)
    if isinstance(value, float): return _number_text(value)
    if isinstance(value, str): return _json_string(value)
    if isinstance(value, list): return "[" + ",".join(_serialize_text(v) for v in value) + "]"
    if isinstance(value, dict):
        if not all(isinstance(k, str) for k in value):
            raise TypeError("canonical JSON object keys must be strings")
        return "{" + ",".join(_json_string(k) + ":" + _serialize_text(value[k]) for k in sorted(value)) + "}"
    raise TypeError(f"unsupported canonical JSON value type: {type(value).__name__}")


def canonical_serialize(value: Any) -> bytes:
    return _serialize_text(value).encode("utf-8")


def canonical_digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_serialize(value)).hexdigest()
