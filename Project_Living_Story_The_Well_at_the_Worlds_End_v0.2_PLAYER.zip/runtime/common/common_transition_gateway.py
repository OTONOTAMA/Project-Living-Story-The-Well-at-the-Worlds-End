#!/usr/bin/env python3
"""Project Living Story Common v0.3 — Domain Transition Gateway reference runtime.

AI / GM Core supplies semantic meaning. Episode/Domain code owns schema-level projection,
semantic validation, authoritative state validation, commit, and re-grounding.

The Host-facing route passes a Semantic Proposal Envelope plus an opaque DomainRuntimeContext;
it does not pass candidate state, raw state paths, or concrete mutations.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha256
import json
from typing import Any, Callable, Dict, List, Mapping, MutableMapping, Optional, Sequence, Tuple

CONTRACT_VERSION = "1.0"
TRANSACTION_STATUSES = (
    "COMMITTED","NO_STATE_CHANGE_AUTHORIZED","PROPOSAL_INVALID","STALE_BASE_STATE",
    "UNRESOLVED_BINDING","SEMANTIC_REJECTED","SCHEMA_REJECTED","INVARIANT_REJECTED",
    "COMMIT_CONFLICT","COMMIT_FAILED",
)
MATERIAL_TRANSACTION_STAGES = (
    "VERIFY_BASE_AUTHORITY","VALIDATE_SPE","RESOLVE_EPISODE_BINDING","SEMANTIC_AUTHORITY_VALIDATE",
    "BUILD_FTR","VALIDATE_FTR_STRUCTURE","VALIDATE_RUNTIME_SCHEMA","VALIDATE_COMMON_EPISODE_INVARIANTS",
    "ATOMIC_COMMIT","REGROUND_COMMITTED_STATE","BUILD_AUTHORIZED_REALIZATION_CONTEXT","RETURN_TRANSACTION_RESULT",
)
FORBIDDEN_PUBLIC_STATE_KEYS = {"candidate_state","state_path","json_pointer","concrete_mutations","commit_receipt"}

class TransitionError(Exception):
    status = "COMMIT_FAILED"
class ProposalInvalid(TransitionError): status = "PROPOSAL_INVALID"
class StaleBaseState(TransitionError): status = "STALE_BASE_STATE"
class UnresolvedBinding(TransitionError): status = "UNRESOLVED_BINDING"
class SemanticRejected(TransitionError): status = "SEMANTIC_REJECTED"
class SchemaRejected(TransitionError): status = "SCHEMA_REJECTED"
class InvariantRejected(TransitionError): status = "INVARIANT_REJECTED"
class CommitConflict(TransitionError): status = "COMMIT_CONFLICT"

@dataclass
class DomainRuntimeContext:
    """Domain-owned runtime handle prepared by Episode bootstrap, not authored from player prose."""
    episode_binding: Mapping[str, Any]
    authority: Optional[Mapping[str, Any]] = None
    binding_resolver: Optional[Callable[[Mapping[str,Any],Mapping[str,Any]],Any]] = None
    semantic_validator: Optional[Callable[[Mapping[str,Any],Mapping[str,Any],Optional[Mapping[str,Any]]],Any]] = None
    apply_constructor: Optional[Callable[[MutableMapping[str,Any],Mapping[str,Any],Mapping[str,Any]],Any]] = None
    validate_state: Optional[Callable[[Mapping[str,Any]],Any]] = None
    common_invariant_validator: Optional[Callable[[Mapping[str,Any],Mapping[str,Any]],Any]] = None
    episode_invariant_validator: Optional[Callable[[Mapping[str,Any],Mapping[str,Any]],Any]] = None
    player_view_projector: Optional[Callable[[Mapping[str,Any]],Mapping[str,Any]]] = None
    no_state_context_projector: Optional[Callable[[Mapping[str,Any],Sequence[Mapping[str,Any]]],Mapping[str,Any]]] = None
    initialization_builder: Optional[Callable[[Mapping[str,Any],Mapping[str,Any]],Mapping[str,Any]]] = None
    commit_finalizer: Optional[Callable[[MutableMapping[str,Any],str,Mapping[str,Any]],Any]] = None


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def digest(value: Any) -> str:
    return sha256(canonical_json(value).encode("utf-8")).hexdigest()

def _ok(value: Any) -> bool:
    if isinstance(value, tuple): return bool(value[0])
    if isinstance(value, Mapping) and "ok" in value: return bool(value["ok"])
    return bool(value)

def _detail(value: Any, default: str) -> str:
    if isinstance(value, tuple) and len(value) > 1: return str(value[1])
    if isinstance(value, Mapping): return str(value.get("detail", value.get("reason", default)))
    return default

def _validate_binding_identity(expected: Mapping[str, Any], actual: Mapping[str, Any]) -> None:
    for key in ("binding_id","binding_version","binding_digest"):
        if not expected.get(key) or expected.get(key) != actual.get(key):
            raise UnresolvedBinding(f"EPISODE_BINDING_IDENTITY_MISMATCH:{key}")

def _scan_forbidden_keys(value: Any, path: str = "$") -> None:
    if isinstance(value, Mapping):
        bad = FORBIDDEN_PUBLIC_STATE_KEYS.intersection(value.keys())
        if bad: raise ProposalInvalid(f"FORBIDDEN_HOST_STATE_FIELD:{path}:{','.join(sorted(bad))}")
        for k,v in value.items(): _scan_forbidden_keys(v,f"{path}.{k}")
    elif isinstance(value,list):
        for i,v in enumerate(value): _scan_forbidden_keys(v,f"{path}[{i}]")


def validate_semantic_proposal(proposal: Mapping[str,Any], *, require_base: bool=True) -> Dict[str,Any]:
    if not isinstance(proposal,Mapping): raise ProposalInvalid("SPE_NOT_OBJECT")
    _scan_forbidden_keys(proposal)
    required=("contract_version","proposal_id","transaction_kind","source_input_digest","episode_binding_identity","semantic_units")
    missing=[k for k in required if k not in proposal]
    if missing: raise ProposalInvalid("SPE_MISSING:"+",".join(missing))
    if proposal.get("contract_version")!=CONTRACT_VERSION: raise ProposalInvalid("SPE_VERSION")
    if proposal.get("transaction_kind") not in {"START_NEW","MATERIAL_TURN","SYSTEM_MATERIAL_ACTION"}: raise ProposalInvalid("SPE_TRANSACTION_KIND")
    if not isinstance(proposal.get("semantic_units"),list) or not proposal["semantic_units"]: raise ProposalInvalid("SPE_SEMANTIC_UNITS")
    if require_base and (not proposal.get("base_commit_id") or not proposal.get("base_state_digest")): raise ProposalInvalid("SPE_BASE_AUTHORITY_REQUIRED")
    for unit in proposal["semantic_units"]:
        if not isinstance(unit,Mapping): raise ProposalInvalid("SEMANTIC_UNIT_NOT_OBJECT")
        for key in ("unit_id","semantic_role","semantic_payload","visibility","persistence_intent"):
            if key not in unit: raise ProposalInvalid(f"SEMANTIC_UNIT_MISSING:{key}")
        if unit["semantic_role"] not in {"ACTION","COMMUNICATION","ASSERTION","PRIVATE_CONTEXT","SYSTEM_INTENT","GENERATED_DETAIL","WORLD_REACTION","OTHER"}: raise ProposalInvalid("SEMANTIC_ROLE")
        if unit["visibility"] not in {"PLAYER_PRIVATE","ACTOR_PRIVATE","PUBLIC_SCENE","SYSTEM_ONLY","UNSPECIFIED"}: raise ProposalInvalid("SEMANTIC_VISIBILITY")
        if not isinstance(unit["semantic_payload"],Mapping): raise ProposalInvalid("SEMANTIC_PAYLOAD_NOT_OBJECT")
    return deepcopy(dict(proposal))


def resolve_episode_binding(proposal: Mapping[str,Any], episode_binding: Mapping[str,Any]) -> Dict[str,Any]:
    if not isinstance(episode_binding,Mapping): raise UnresolvedBinding("EPISODE_BINDING_NOT_OBJECT")
    for key in ("binding_id","binding_version","episode_id","runtime_schema_identity","constructors","semantic_validators","initialization_binding","generated_blank_policy"):
        if key not in episode_binding: raise UnresolvedBinding(f"EPISODE_BINDING_MISSING:{key}")
    actual={
        "binding_id":episode_binding.get("binding_id"),"binding_version":episode_binding.get("binding_version"),
        "binding_digest":episode_binding.get("binding_digest") or digest({k:v for k,v in episode_binding.items() if k!="binding_digest"}),
    }
    _validate_binding_identity(proposal["episode_binding_identity"],actual)
    return deepcopy(dict(episode_binding))


def _allowed_blank(binding: Mapping[str,Any], unit: Mapping[str,Any], constructor: Optional[Mapping[str,Any]]) -> bool:
    blank_class=unit.get("semantic_payload",{}).get("blank_class")
    if not blank_class: return True
    allowed=set(binding.get("generated_blank_policy",{}).get("allowed_classes",[]) or [])
    if constructor: allowed.update(constructor.get("generation_blank_classes",[]) or [])
    return blank_class in allowed


def validate_semantic_authority(
    proposal: Mapping[str,Any], episode_binding: Mapping[str,Any], *,
    binding_resolver: Optional[Callable[[Mapping[str,Any],Mapping[str,Any]],Any]]=None,
    semantic_validator: Optional[Callable[[Mapping[str,Any],Mapping[str,Any],Optional[Mapping[str,Any]]],Any]]=None,
) -> List[Dict[str,Any]]:
    constructors={c.get("constructor_id"):c for c in episode_binding.get("constructors",[]) if isinstance(c,Mapping) and c.get("constructor_id")}
    resolved=[]
    for unit in proposal["semantic_units"]:
        decision=binding_resolver(unit,episode_binding) if binding_resolver else None
        if decision is None:
            if unit.get("persistence_intent") in {"NONE","EPHEMERAL"}: decision={"no_state_change":True}
            else:
                candidates=[c for c in constructors.values() if unit.get("semantic_role") in set(c.get("accepted_semantic_roles",[]))]
                if len(candidates)==1: decision={"constructor_id":candidates[0]["constructor_id"]}
                else: raise UnresolvedBinding(f"UNRESOLVED_UNIT:{unit.get('unit_id')}")
        if isinstance(decision,str): decision={"constructor_id":decision}
        if not isinstance(decision,Mapping): raise UnresolvedBinding(f"INVALID_BINDING_DECISION:{unit.get('unit_id')}")
        if decision.get("reject"): raise SemanticRejected(str(decision.get("reason") or f"SEMANTIC_REJECTED:{unit.get('unit_id')}"))
        if decision.get("no_state_change"):
            resolved.append({"unit":deepcopy(unit),"no_state_change":True,"constructor":None}); continue
        cid=decision.get("constructor_id"); constructor=constructors.get(cid)
        if not constructor: raise UnresolvedBinding(f"UNKNOWN_CONSTRUCTOR:{cid}")
        if unit.get("semantic_role") not in set(constructor.get("accepted_semantic_roles",[])): raise SemanticRejected(f"CONSTRUCTOR_ROLE_MISMATCH:{unit.get('unit_id')}:{cid}")
        if unit.get("semantic_role")=="GENERATED_DETAIL" and not _allowed_blank(episode_binding,unit,constructor): raise SemanticRejected(f"UNAUTHORIZED_GENERATED_BLANK:{unit.get('unit_id')}")
        if semantic_validator is not None:
            verdict=semantic_validator(unit,episode_binding,constructor)
            if not _ok(verdict): raise SemanticRejected(_detail(verdict,f"SEMANTIC_VALIDATOR:{unit.get('unit_id')}"))
        resolved.append({"unit":deepcopy(unit),"no_state_change":False,"constructor":deepcopy(constructor),"decision":deepcopy(dict(decision))})
    return resolved


def build_formal_transition(proposal: Mapping[str,Any], episode_binding: Mapping[str,Any], resolved_units: Sequence[Mapping[str,Any]]) -> Dict[str,Any]:
    concrete=[]; semantic=[]
    for idx,item in enumerate(resolved_units):
        unit=item["unit"]
        semantic.append({"unit_id":unit["unit_id"],"semantic_role":unit["semantic_role"],"semantic_payload":deepcopy(unit["semantic_payload"]),"visibility":unit["visibility"],"persistence_intent":unit["persistence_intent"]})
        if item.get("no_state_change"): continue
        c=item["constructor"]; decision=item.get("decision",{})
        concrete.append({
            "mutation_id":f"M{idx+1:04d}","constructor_id":c["constructor_id"],
            "mutation_kind":str(decision.get("mutation_kind") or c.get("output_semantic_class") or "EPISODE_CONSTRUCT"),
            "target_ref":decision.get("target_ref") or unit.get("semantic_payload",{}).get("target_ref"),
            "payload":deepcopy(dict(unit["semantic_payload"])),
        })
    return {
        "contract_version":CONTRACT_VERSION,"transition_id":f"TRN.{proposal['proposal_id']}","proposal_id":proposal["proposal_id"],"proposal_digest":digest(proposal),
        "base_commit_id":proposal.get("base_commit_id") or "GENESIS","base_state_digest":proposal.get("base_state_digest") or "GENESIS",
        "episode_binding_identity":deepcopy(proposal["episode_binding_identity"]),"semantic_effects":semantic,"concrete_mutations":concrete,
        "observation_updates":[],"knowledge_updates":[],"relationship_updates":[],"process_updates":[],"provenance_updates":[],"validation_state":"SEMANTIC_VALID",
    }


def validate_ftr_structure(ftr: Mapping[str,Any]) -> Dict[str,Any]:
    required=("contract_version","transition_id","proposal_id","proposal_digest","base_commit_id","base_state_digest","episode_binding_identity","semantic_effects","concrete_mutations","validation_state")
    missing=[k for k in required if k not in ftr]
    if missing: raise SchemaRejected("FTR_MISSING:"+",".join(missing))
    if ftr.get("contract_version")!=CONTRACT_VERSION: raise SchemaRejected("FTR_VERSION")
    if not isinstance(ftr.get("concrete_mutations"),list): raise SchemaRejected("FTR_MUTATIONS")
    for m in ftr["concrete_mutations"]:
        if not isinstance(m,Mapping): raise SchemaRejected("FTR_MUTATION_OBJECT")
        for k in ("mutation_id","constructor_id","mutation_kind","target_ref","payload"):
            if k not in m: raise SchemaRejected(f"FTR_MUTATION_MISSING:{k}")
    out=deepcopy(dict(ftr)); out["validation_state"]="STRUCTURAL_VALID"; return out


def _validate_current_authority(proposal: Mapping[str,Any], authority: Mapping[str,Any]) -> None:
    if proposal.get("base_commit_id")!=authority.get("commit_id") or proposal.get("base_state_digest")!=authority.get("state_digest"): raise StaleBaseState("BASE_AUTHORITY_MISMATCH")


def atomic_commit_transition(
    authority: Mapping[str,Any], ftr: Mapping[str,Any], *,
    apply_constructor: Callable[[MutableMapping[str,Any],Mapping[str,Any],Mapping[str,Any]],Any],
    validate_state: Optional[Callable[[Mapping[str,Any]],Any]]=None,
    common_invariant_validator: Optional[Callable[[Mapping[str,Any],Mapping[str,Any]],Any]]=None,
    episode_invariant_validator: Optional[Callable[[Mapping[str,Any],Mapping[str,Any]],Any]]=None,
    commit_finalizer: Optional[Callable[[MutableMapping[str,Any],str,Mapping[str,Any]],Any]]=None,
) -> Tuple[Dict[str,Any],Dict[str,Any]]:
    if ftr.get("base_commit_id")!=authority.get("commit_id") or ftr.get("base_state_digest")!=authority.get("state_digest"): raise CommitConflict("COMMIT_BASE_MISMATCH")
    state=deepcopy(authority.get("state",{})); binding_stub={"episode_binding_identity":deepcopy(ftr.get("episode_binding_identity"))}
    try:
        for mutation in ftr.get("concrete_mutations",[]):
            result=apply_constructor(state,mutation,binding_stub)
            if result is not None: state=deepcopy(result)
    except TransitionError: raise
    except Exception as e: raise CommitConflict(f"CONSTRUCTOR_ERROR:{type(e).__name__}:{e}") from e
    if commit_finalizer is not None:
        try:
            finalized=commit_finalizer(state,ftr["transition_id"],ftr)
            if finalized is not None: state=deepcopy(finalized)
        except TransitionError: raise
        except Exception as e: raise CommitConflict(f"COMMIT_FINALIZER_ERROR:{type(e).__name__}:{e}") from e
    if validate_state is not None:
        verdict=validate_state(state)
        if not _ok(verdict): raise SchemaRejected(_detail(verdict,"RUNTIME_STATE_SCHEMA_REJECTED"))
    if common_invariant_validator is not None:
        verdict=common_invariant_validator(state,ftr)
        if not _ok(verdict): raise InvariantRejected(_detail(verdict,"COMMON_INVARIANT_REJECTED"))
    if episode_invariant_validator is not None:
        verdict=episode_invariant_validator(state,ftr)
        if not _ok(verdict): raise InvariantRejected(_detail(verdict,"EPISODE_INVARIANT_REJECTED"))
    new_commit_id=ftr["transition_id"]; state_digest=digest(state)
    receipt={"status":"PASS","commit_id":new_commit_id,"prior_commit_id":authority.get("commit_id"),"prior_state_digest":authority.get("state_digest"),"state_digest":state_digest,"proposal_digest":ftr.get("proposal_digest"),"transition_digest":digest(ftr),"episode_binding_identity":deepcopy(ftr.get("episode_binding_identity"))}
    return {"commit_id":new_commit_id,"state_digest":state_digest,"state":state},receipt


def reground_committed_state(committed_authority: Mapping[str,Any]) -> Dict[str,Any]:
    return deepcopy(dict(committed_authority))


def build_authorized_realization_context(
    committed_authority: Optional[Mapping[str,Any]], *, display_language: str,
    player_view_projector: Optional[Callable[[Mapping[str,Any]],Mapping[str,Any]]]=None,
    state_advanced: bool=True, no_state_context: Optional[Mapping[str,Any]]=None,
) -> Dict[str,Any]:
    if state_advanced:
        if committed_authority is None: raise CommitConflict("ARC_REQUIRES_COMMITTED_AUTHORITY")
        view=player_view_projector(committed_authority) if player_view_projector else deepcopy(committed_authority.get("state",{}))
        return {"contract_version":CONTRACT_VERSION,"authorization_kind":"COMMITTED_STATE","state_advanced":True,"commit_id":committed_authority.get("commit_id"),"state_digest":committed_authority.get("state_digest"),"player_visible_delta":{},"player_visible_context":deepcopy(dict(view)),"actor_view_constraints":[],"display_language":display_language or "und","provenance_hints":[]}
    return {"contract_version":CONTRACT_VERSION,"authorization_kind":"NO_STATE_CHANGE","state_advanced":False,"commit_id":None,"state_digest":None,"player_visible_delta":{},"player_visible_context":deepcopy(dict(no_state_context or {})),"actor_view_constraints":[],"display_language":display_language or "und","provenance_hints":[]}


def _result(transaction_id: str,status: str,*,state_advanced: bool=False,receipt: Any=None,arc: Any=None,failure: Any=None) -> Dict[str,Any]:
    return {"contract_version":CONTRACT_VERSION,"transaction_id":transaction_id,"status":status,"state_advanced":bool(state_advanced),"commit_receipt":deepcopy(receipt),"authorized_realization_context":deepcopy(arc),"failure":deepcopy(failure)}


def execute_material_turn(semantic_proposal: Mapping[str,Any], runtime_context: DomainRuntimeContext) -> Dict[str,Any]:
    """Public material-turn transaction. runtime_context is created by Episode bootstrap."""
    tx=str(semantic_proposal.get("proposal_id","UNKNOWN")) if isinstance(semantic_proposal,Mapping) else "UNKNOWN"
    try:
        if runtime_context.authority is None: raise StaleBaseState("NO_ACTIVE_AUTHORITY")
        proposal=validate_semantic_proposal(semantic_proposal,require_base=True)
        _validate_current_authority(proposal,runtime_context.authority)
        binding=resolve_episode_binding(proposal,runtime_context.episode_binding)
        resolved=validate_semantic_authority(proposal,binding,binding_resolver=runtime_context.binding_resolver,semantic_validator=runtime_context.semantic_validator)
        ftr=validate_ftr_structure(build_formal_transition(proposal,binding,resolved))
        if not ftr["concrete_mutations"]:
            context=runtime_context.no_state_context_projector(proposal,resolved) if runtime_context.no_state_context_projector else {"semantic_units":[deepcopy(x["unit"]) for x in resolved]}
            arc=build_authorized_realization_context(None,display_language=proposal.get("display_language","und"),state_advanced=False,no_state_context=context)
            return _result(tx,"NO_STATE_CHANGE_AUTHORIZED",state_advanced=False,arc=arc)
        if runtime_context.apply_constructor is None: raise UnresolvedBinding("EPISODE_APPLY_CONSTRUCTOR_REQUIRED")
        committed,receipt=atomic_commit_transition(
            runtime_context.authority,ftr,apply_constructor=runtime_context.apply_constructor,
            validate_state=runtime_context.validate_state,common_invariant_validator=runtime_context.common_invariant_validator,
            episode_invariant_validator=runtime_context.episode_invariant_validator,commit_finalizer=runtime_context.commit_finalizer)
        runtime_context.authority=reground_committed_state(committed)
        arc=build_authorized_realization_context(runtime_context.authority,display_language=proposal.get("display_language","und"),player_view_projector=runtime_context.player_view_projector,state_advanced=True)
        return _result(tx,"COMMITTED",state_advanced=True,receipt=receipt,arc=arc)
    except TransitionError as e:
        return _result(tx,e.status,state_advanced=False,failure={"stage_status":e.status,"message":str(e)})
    except Exception as e:
        return _result(tx,"COMMIT_FAILED",state_advanced=False,failure={"stage_status":"COMMIT_FAILED","message":f"{type(e).__name__}:{e}"})


def start_new(semantic_proposal: Mapping[str,Any], runtime_context: DomainRuntimeContext) -> Dict[str,Any]:
    """Public NEW GAME transaction. Episode bootstrap provides the initializer in runtime_context."""
    tx=str(semantic_proposal.get("proposal_id","START_NEW")) if isinstance(semantic_proposal,Mapping) else "START_NEW"
    try:
        proposal=validate_semantic_proposal(semantic_proposal,require_base=False)
        if proposal.get("transaction_kind")!="START_NEW": raise ProposalInvalid("START_NEW_TRANSACTION_KIND_REQUIRED")
        binding=resolve_episode_binding(proposal,runtime_context.episode_binding)
        if runtime_context.initialization_builder is None: raise UnresolvedBinding("EPISODE_INITIALIZATION_BUILDER_REQUIRED")
        try: state=deepcopy(dict(runtime_context.initialization_builder(proposal,binding)))
        except Exception as e: raise CommitConflict(f"INITIALIZER_ERROR:{type(e).__name__}:{e}") from e
        genesis_ftr={"transition_id":f"GENESIS.{proposal['proposal_id']}","proposal_id":proposal["proposal_id"]}
        if runtime_context.commit_finalizer is not None:
            try:
                finalized=runtime_context.commit_finalizer(state,genesis_ftr["transition_id"],genesis_ftr)
                if finalized is not None: state=deepcopy(finalized)
            except TransitionError: raise
            except Exception as e: raise CommitConflict(f"INITIALIZATION_FINALIZER_ERROR:{type(e).__name__}:{e}") from e
        if runtime_context.validate_state is not None:
            verdict=runtime_context.validate_state(state)
            if not _ok(verdict): raise SchemaRejected(_detail(verdict,"INITIAL_STATE_SCHEMA_REJECTED"))
        if runtime_context.common_invariant_validator is not None:
            verdict=runtime_context.common_invariant_validator(state,genesis_ftr)
            if not _ok(verdict): raise InvariantRejected(_detail(verdict,"COMMON_INITIALIZATION_INVARIANT_REJECTED"))
        if runtime_context.episode_invariant_validator is not None:
            verdict=runtime_context.episode_invariant_validator(state,genesis_ftr)
            if not _ok(verdict): raise InvariantRejected(_detail(verdict,"EPISODE_INITIALIZATION_INVARIANT_REJECTED"))
        runtime_context.authority={"commit_id":f"GENESIS.{proposal['proposal_id']}","state_digest":digest(state),"state":state}
        receipt={"status":"PASS","commit_id":runtime_context.authority["commit_id"],"prior_commit_id":None,"prior_state_digest":None,"state_digest":runtime_context.authority["state_digest"],"proposal_digest":digest(proposal),"transition_digest":digest(genesis_ftr),"episode_binding_identity":deepcopy(proposal["episode_binding_identity"])}
        runtime_context.authority=reground_committed_state(runtime_context.authority)
        arc=build_authorized_realization_context(runtime_context.authority,display_language=proposal.get("display_language","und"),player_view_projector=runtime_context.player_view_projector,state_advanced=True)
        return _result(tx,"COMMITTED",state_advanced=True,receipt=receipt,arc=arc)
    except TransitionError as e:
        return _result(tx,e.status,state_advanced=False,failure={"stage_status":e.status,"message":str(e)})
    except Exception as e:
        return _result(tx,"COMMIT_FAILED",state_advanced=False,failure={"stage_status":"COMMIT_FAILED","message":f"{type(e).__name__}:{e}"})
