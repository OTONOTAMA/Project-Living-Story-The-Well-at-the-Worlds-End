#!/usr/bin/env python3
"""Project Living Story Common v0.5 — Machine-First Turn Controller.

The controller owns formal per-turn routing. The outer chat model supplies only
semantic and realization candidates. It cannot directly authorize state mutation
or NO_STATE_CHANGE. Domain authority remains in common_transition_gateway and the
Episode runtime context.

Framework source binding:
- ChatGPT Bundle Framework v0.20 STABLE
- SHA-256 9de31d5ff04a2336e822cb5ab712575f11a17b13cd0c33ddd09b4ef07ff1084a
- Reused semantics: controlled execution, permits, receipts, provenance, canonical digests.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Sequence
import importlib.util
import re
import sys
import uuid


def _load_sibling(module_name: str, filename: str):
    path = Path(__file__).with_name(filename)
    key = f"pls_common_v05_{module_name}"
    if key in sys.modules:
        return sys.modules[key]
    spec = importlib.util.spec_from_file_location(key, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load {filename}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    spec.loader.exec_module(module)
    return module


gw = _load_sibling("gateway", "common_transition_gateway.py")
control_digest = _load_sibling("digest", "pls_control_digest.py")
canonical_digest = control_digest.canonical_digest

CONTROL_CONTRACT_VERSION = "1.0"
ARC_CONTRACT_VERSION = "2.0"
FRAMEWORK_SOURCE_SHA256 = "9de31d5ff04a2336e822cb5ab712575f11a17b13cd0c33ddd09b4ef07ff1084a"
PHASES = {
    "WAIT_INPUT", "SEMANTIC_REQUEST_ISSUED", "SEMANTIC_RESPONSE_ACCEPTED",
    "TRANSACTION_RESOLVED", "REALIZATION_REQUEST_ISSUED",
    "REALIZATION_RESPONSE_ACCEPTED", "EMISSION_AUTHORIZED", "BLOCKED", "CANCELLED",
}
PERMIT_STATUSES = {"ISSUED", "CONSUMED", "INVALIDATED"}
SUCCESS_TRANSACTION_STATUSES = {"COMMITTED", "NO_STATE_CHANGE_AUTHORIZED"}
ALLOWED_SEMANTIC_ROLES = {
    "ACTION", "COMMUNICATION", "ASSERTION", "PRIVATE_CONTEXT", "SYSTEM_INTENT",
    "GENERATED_DETAIL", "WORLD_REACTION", "OTHER",
}
ALLOWED_VISIBILITY = {"PLAYER_PRIVATE", "ACTOR_PRIVATE", "PUBLIC_SCENE", "SYSTEM_ONLY", "UNSPECIFIED"}
ALLOWED_PERSISTENCE = {"NONE", "EPHEMERAL", "MAY_PERSIST", "MUST_VALIDATE_FOR_PERSISTENCE"}
AUTHORITY_SENSITIVE_HOST_KEYS = {
    "proposal_id", "base_commit_id", "base_state_digest", "source_input_digest",
    "episode_binding_identity", "commit_id", "state_digest", "candidate_state",
    "concrete_mutations", "state_path", "json_pointer", "commit_receipt",
}


class TurnControlError(Exception):
    pass


class TurnPhaseError(TurnControlError):
    pass


class StaleTurnError(TurnControlError):
    pass


class HostResponseError(TurnControlError):
    pass


class SaveBoundaryError(TurnControlError):
    pass


class PLSTurnController:
    """Small PLS-specific controller for chat-hosted Machine-first turn execution."""

    def __init__(
        self,
        runtime_context: Any,
        *,
        session_id: Optional[str] = None,
        semantic_context_provider: Optional[Callable[[Mapping[str, Any], str], Mapping[str, Any]]] = None,
        presentation_contract: Optional[Mapping[str, Any]] = None,
    ):
        if runtime_context is None:
            raise TurnControlError("runtime_context is required")
        if getattr(runtime_context, "binding_resolver", None) is None:
            raise TurnControlError("MACHINE_FIRST_V1 requires an Episode-owned binding_resolver; Host persistence hints cannot own commit/no-state routing")
        if getattr(runtime_context, "player_view_projector", None) is None:
            raise TurnControlError("MACHINE_FIRST_V1 requires a player_view_projector; full authoritative state must not be exposed as a fallback realization context")
        self.runtime_context = runtime_context
        self.session_id = session_id or ("PLS-SESSION-" + uuid.uuid4().hex[:16])
        self.semantic_context_provider = semantic_context_provider
        self.presentation_contract = deepcopy(dict(presentation_contract or {
            "mode": "PLAYER_FACING_IN_WORLD",
            "internal_ids_visible_by_default": False,
            "machine_marker_required_for_formal_output": True,
            "marker_semantics": "ROUTE_PROVENANCE_NOT_SENTENCE_LEVEL_FACT_CERTIFICATION",
        }))
        self._turn_sequence = 0
        self._phase = "WAIT_INPUT"
        self._current: Optional[Dict[str, Any]] = None
        self._permits: Dict[str, Dict[str, Any]] = {}
        self._receipts: Dict[str, Dict[str, Any]] = {}
        self._provenance: Dict[str, Dict[str, Any]] = {}
        self._archived_turns: list[Dict[str, Any]] = []
        self._last_receipt_id: Optional[str] = None
        self._last_recovery_note: Optional[str] = None

    # ---------- public host-facing Machine surface ----------

    def begin_turn(
        self,
        raw_user_input: str,
        *,
        display_language: str = "und",
        actor_ref: Optional[str] = None,
        target_refs: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        self._require_phase("WAIT_INPUT")
        if not isinstance(raw_user_input, str) or not raw_user_input.strip():
            raise HostResponseError("raw_user_input must be a non-empty string")
        authority = self._authority_snapshot()
        self._turn_sequence += 1
        turn_id = f"T{self._turn_sequence:06d}"
        source_input = {
            "raw_user_input": raw_user_input,
            "display_language": display_language or "und",
            "actor_ref": actor_ref,
            "target_refs": list(target_refs or []),
        }
        source_input_digest = canonical_digest(source_input)
        binding_identity = self._episode_binding_identity()
        authority_context = self._player_authority_context(authority)
        authority_context_digest = canonical_digest(authority_context)
        additional_context: Dict[str, Any] = {}
        if self.semantic_context_provider is not None:
            supplied = self.semantic_context_provider(deepcopy(authority), raw_user_input)
            if supplied is not None:
                if not isinstance(supplied, Mapping):
                    raise TurnControlError("semantic_context_provider must return a mapping")
                additional_context = deepcopy(dict(supplied))
        request_id = f"SREQ.{self.session_id}.{turn_id}.{source_input_digest.split(':',1)[-1][:12]}"
        permit = self._issue_permit(
            stage="SEMANTIC_RESPONSE",
            turn_id=turn_id,
            request_id=request_id,
            base_commit_id=authority["commit_id"],
            base_state_digest=authority["state_digest"],
            input_digest=source_input_digest,
        )
        request = {
            "contract_version": CONTROL_CONTRACT_VERSION,
            "session_id": self.session_id,
            "turn_id": turn_id,
            "request_id": request_id,
            "permit_id": permit["permit_id"],
            "raw_user_input": raw_user_input,
            "source_input_digest": source_input_digest,
            "base_commit_id": authority["commit_id"],
            "base_state_digest": authority["state_digest"],
            "episode_binding_identity": binding_identity,
            "authority_context": authority_context,
            "authority_context_digest": authority_context_digest,
            "additional_machine_context": additional_context,
            "expected_response_contract": {
                "id": "PLS_HOST_SEMANTIC_RESPONSE_v1",
                "version": "1.0",
                "authority_class": "CANDIDATE",
                "machine_owned_fields_must_not_be_authored": sorted(AUTHORITY_SENSITIVE_HOST_KEYS),
            },
            "display_language": display_language or "und",
        }
        self._current = {
            "turn_id": turn_id,
            "raw_user_input": raw_user_input,
            "display_language": display_language or "und",
            "actor_ref": actor_ref,
            "target_refs": list(target_refs or []),
            "source_input_digest": source_input_digest,
            "base_commit_id": authority["commit_id"],
            "base_state_digest": authority["state_digest"],
            "episode_binding_identity": binding_identity,
            "semantic_request": deepcopy(request),
            "semantic_request_digest": canonical_digest(request),
            "semantic_response": None,
            "machine_semantic_proposal": None,
            "transaction_result": None,
            "authorized_realization_context": None,
            "realization_request": None,
            "realization_response": None,
            "receipt_id": None,
        }
        self._phase = "SEMANTIC_REQUEST_ISSUED"
        return deepcopy(request)

    def submit_semantic_response(self, response: Mapping[str, Any]) -> Dict[str, Any]:
        self._require_phase("SEMANTIC_REQUEST_ISSUED")
        current = self._require_current()
        validated = self._validate_host_semantic_response(response)
        if validated["request_id"] != current["semantic_request"]["request_id"]:
            raise StaleTurnError("semantic response request_id does not match current Machine request")
        self._require_authority_matches_base(current)
        self._consume_permit(current["semantic_request"]["permit_id"], stage="SEMANTIC_RESPONSE")
        self._phase = "SEMANTIC_RESPONSE_ACCEPTED"
        current["semantic_response"] = deepcopy(validated)

        proposal = self._build_machine_semantic_proposal(validated, current)
        current["machine_semantic_proposal"] = deepcopy(proposal)
        transaction = self._execute_machine_routed_transaction(proposal)
        current["transaction_result"] = deepcopy(transaction)
        if transaction.get("status") not in SUCCESS_TRANSACTION_STATUSES:
            self._phase = "BLOCKED"
            current["block_reason"] = str((transaction.get("failure") or {}).get("message") or transaction.get("status") or "TRANSACTION_BLOCKED")
            return {
                "status": "BLOCKED",
                "turn_id": current["turn_id"],
                "machine_semantic_proposal": deepcopy(proposal),
                "transaction_result": deepcopy(transaction),
                "turn_status": self.turn_status(),
            }

        self._phase = "TRANSACTION_RESOLVED"
        arc = self._build_machine_arc_v2(transaction, proposal, current)
        current["authorized_realization_context"] = deepcopy(arc)
        realization_request = self._issue_realization_request(transaction, arc, current)
        current["realization_request"] = deepcopy(realization_request)
        self._phase = "REALIZATION_REQUEST_ISSUED"
        return {
            "status": "REALIZATION_REQUEST_ISSUED",
            "turn_id": current["turn_id"],
            "machine_semantic_proposal": deepcopy(proposal),
            "transaction_result": deepcopy(transaction),
            "authorized_realization_context": deepcopy(arc),
            "realization_request": deepcopy(realization_request),
        }

    def submit_realization(self, response: Mapping[str, Any]) -> Dict[str, Any]:
        self._require_phase("REALIZATION_REQUEST_ISSUED")
        current = self._require_current()
        if not isinstance(response, Mapping):
            raise HostResponseError("realization response must be an object")
        if set(response.keys()) - {"request_id", "text"}:
            raise HostResponseError("realization response contains undeclared fields")
        request_id = response.get("request_id")
        text = response.get("text")
        if not isinstance(request_id, str) or request_id != current["realization_request"]["request_id"]:
            raise StaleTurnError("realization response request_id does not match current Machine request")
        if not isinstance(text, str) or not text.strip():
            raise HostResponseError("realization text must be non-empty")
        self._require_authority_matches_result(current)
        self._consume_permit(current["realization_request"]["permit_id"], stage="REALIZATION_RESPONSE")
        self._phase = "REALIZATION_RESPONSE_ACCEPTED"
        current["realization_response"] = {"request_id": request_id, "text": text}

        output_digest = canonical_digest({"text": text})
        transaction = current["transaction_result"]
        authority = self._authority_snapshot()
        receipt_core = {
            "contract_version": CONTROL_CONTRACT_VERSION,
            "session_id": self.session_id,
            "turn_id": current["turn_id"],
            "semantic_request_id": current["semantic_request"]["request_id"],
            "transaction_id": transaction["transaction_id"],
            "transaction_status": transaction["status"],
            "base_commit_id": current["base_commit_id"],
            "base_state_digest": current["base_state_digest"],
            "result_commit_id": authority["commit_id"],
            "result_state_digest": authority["state_digest"],
            "realization_request_id": current["realization_request"]["request_id"],
            "output_digest": output_digest,
            "status": "EMISSION_AUTHORIZED",
        }
        receipt_id = "TRCPT." + uuid.uuid4().hex
        fingerprint = canonical_digest(receipt_core).split(":", 1)[-1][:12].upper()
        receipt = {"receipt_id": receipt_id, "fingerprint": fingerprint, **receipt_core}
        marker = self._format_marker(current["turn_id"], transaction["status"], authority["commit_id"], fingerprint)
        provenance = {
            "contract_version": CONTROL_CONTRACT_VERSION,
            "receipt_id": receipt_id,
            "receipt_fingerprint": fingerprint,
            "turn_id": current["turn_id"],
            "output_digest": output_digest,
            "marker": marker,
            "authority_status": "EMISSION_AUTHORIZED",
        }
        self._receipts[receipt_id] = deepcopy(receipt)
        self._provenance[receipt_id] = deepcopy(provenance)
        self._last_receipt_id = receipt_id
        current["receipt_id"] = receipt_id
        self._phase = "EMISSION_AUTHORIZED"
        archived = deepcopy(current)
        archived["final_phase"] = "EMISSION_AUTHORIZED"
        archived["receipt"] = deepcopy(receipt)
        archived["provenance"] = deepcopy(provenance)
        self._archived_turns.append(archived)
        self._current = None
        self._phase = "WAIT_INPUT"
        return {
            "status": "EMISSION_AUTHORIZED",
            "turn_id": receipt["turn_id"],
            "receipt_id": receipt_id,
            "receipt_fingerprint": fingerprint,
            "marker": marker,
            "text": text,
            "output_digest": output_digest,
            "result_commit_id": receipt["result_commit_id"],
            "result_state_digest": receipt["result_state_digest"],
            "provenance": deepcopy(provenance),
        }

    def turn_status(self) -> Dict[str, Any]:
        authority = self._authority_snapshot(allow_none=True)
        current = self._current or {}
        return {
            "contract_version": CONTROL_CONTRACT_VERSION,
            "session_id": self.session_id,
            "turn_sequence": self._turn_sequence,
            "phase": self._phase,
            "turn_id": current.get("turn_id"),
            "base_commit_id": current.get("base_commit_id"),
            "base_state_digest": current.get("base_state_digest"),
            "semantic_request_id": (current.get("semantic_request") or {}).get("request_id"),
            "realization_request_id": (current.get("realization_request") or {}).get("request_id"),
            "current_authority_commit_id": authority.get("commit_id") if authority else None,
            "current_authority_state_digest": authority.get("state_digest") if authority else None,
            "last_receipt_id": self._last_receipt_id,
            "block_reason": current.get("block_reason"),
            "last_recovery_note": self._last_recovery_note,
        }

    def verify_receipt(
        self,
        reference: str,
        *,
        expected_turn_id: Optional[str] = None,
        output_text: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not isinstance(reference, str) or not reference:
            return {"valid": False, "reason": "INVALID_REFERENCE"}
        receipt = self._find_receipt(reference)
        if receipt is None:
            return {"valid": False, "reason": "RECEIPT_NOT_FOUND"}
        core = {k: deepcopy(v) for k, v in receipt.items() if k not in {"receipt_id", "fingerprint"}}
        expected_fp = canonical_digest(core).split(":", 1)[-1][:12].upper()
        if expected_fp != receipt.get("fingerprint"):
            return {"valid": False, "reason": "RECEIPT_FINGERPRINT_MISMATCH"}
        provenance = self._provenance.get(receipt["receipt_id"])
        if provenance is None or provenance.get("receipt_fingerprint") != receipt.get("fingerprint"):
            return {"valid": False, "reason": "PROVENANCE_MISSING_OR_MISMATCH"}
        if expected_turn_id is not None and receipt.get("turn_id") != expected_turn_id:
            return {"valid": False, "reason": "TURN_MISMATCH"}
        if output_text is not None:
            actual_output = canonical_digest({"text": output_text})
            if actual_output != receipt.get("output_digest"):
                return {"valid": False, "reason": "OUTPUT_DIGEST_MISMATCH"}
        return {"valid": True, "receipt": deepcopy(receipt), "provenance": deepcopy(provenance)}

    def require_finalized_turn_boundary(self) -> Dict[str, Any]:
        if self._phase != "WAIT_INPUT" or self._current is not None:
            raise SaveBoundaryError("formal SAVE/export is allowed only at a finalized turn boundary")
        authority = self._authority_snapshot()
        return {
            "status": "FINALIZED_TURN_BOUNDARY",
            "session_id": self.session_id,
            "turn_sequence": self._turn_sequence,
            "current_commit_id": authority["commit_id"],
            "current_state_digest": authority["state_digest"],
            "last_receipt_id": self._last_receipt_id,
        }

    def cancel_turn(self, reason: str = "HOST_REQUESTED_CANCEL") -> Dict[str, Any]:
        """Cancel only while no authoritative transaction has completed.

        Once COMMITTED/NO_STATE_CHANGE_AUTHORIZED exists, Framework-compatible
        recovery preserves that completed Machine stage and requires realization
        retry rather than silently discarding it.
        """
        if self._phase == "WAIT_INPUT":
            return {"status": "NO_ACTIVE_TURN", **self.turn_status()}
        current = self._require_current()
        transaction = current.get("transaction_result") or {}
        if transaction.get("status") in SUCCESS_TRANSACTION_STATUSES:
            raise TurnPhaseError("authoritative transaction already resolved; retry/finalize realization instead of cancelling the turn")
        for permit in self._permits.values():
            if permit.get("turn_id") == current.get("turn_id") and permit.get("status") == "ISSUED":
                permit["status"] = "INVALIDATED"
        cancelled_turn_id = current["turn_id"]
        self._archived_turns.append({**deepcopy(current), "final_phase": "CANCELLED", "cancel_reason": str(reason)})
        self._current = None
        self._phase = "WAIT_INPUT"
        return {"status": "CANCELLED", "turn_id": cancelled_turn_id, "reason": str(reason), "turn_status": self.turn_status()}

    def retry_realization(self) -> Dict[str, Any]:
        """Reissue the realization request for an already resolved transaction."""
        current = self._require_current()
        transaction = current.get("transaction_result") or {}
        arc = current.get("authorized_realization_context") or {}
        if transaction.get("status") not in SUCCESS_TRANSACTION_STATUSES or not arc:
            raise TurnPhaseError("no completed authoritative transaction is available for realization retry")
        self._require_authority_matches_result(current)
        old = current.get("realization_request") or {}
        old_permit = old.get("permit_id")
        if old_permit in self._permits and self._permits[old_permit].get("status") == "ISSUED":
            self._permits[old_permit]["status"] = "INVALIDATED"
        request = self._issue_realization_request(transaction, arc, current)
        current["realization_request"] = deepcopy(request)
        current["realization_response"] = None
        self._phase = "REALIZATION_REQUEST_ISSUED"
        return deepcopy(request)

    def export_controller_metadata(self) -> Dict[str, Any]:
        """Host-session metadata only; never fictional world state."""
        return {
            "schema": "PLS_TURN_CONTROLLER_METADATA_V1",
            "framework_source_sha256": FRAMEWORK_SOURCE_SHA256,
            "session_id": self.session_id,
            "turn_sequence": self._turn_sequence,
            "phase": self._phase,
            "last_receipt_id": self._last_receipt_id,
            "receipts": deepcopy(self._receipts),
            "provenance": deepcopy(self._provenance),
            "pending_turn": deepcopy(self._current),
        }

    @classmethod
    def restore_controller_metadata(
        cls,
        runtime_context: Any,
        metadata: Mapping[str, Any],
        *,
        semantic_context_provider: Optional[Callable[[Mapping[str, Any], str], Mapping[str, Any]]] = None,
        presentation_contract: Optional[Mapping[str, Any]] = None,
    ) -> "PLSTurnController":
        if not isinstance(metadata, Mapping) or metadata.get("schema") != "PLS_TURN_CONTROLLER_METADATA_V1":
            raise TurnControlError("invalid controller metadata")
        controller = cls(
            runtime_context,
            session_id=str(metadata.get("session_id") or ("PLS-SESSION-" + uuid.uuid4().hex[:16])),
            semantic_context_provider=semantic_context_provider,
            presentation_contract=presentation_contract,
        )
        controller._turn_sequence = int(metadata.get("turn_sequence") or 0)
        receipts = metadata.get("receipts") or {}
        provenance = metadata.get("provenance") or {}
        if not isinstance(receipts, Mapping) or not isinstance(provenance, Mapping):
            raise TurnControlError("invalid receipt/provenance metadata")
        controller._receipts = deepcopy(dict(receipts))
        controller._provenance = deepcopy(dict(provenance))
        controller._last_receipt_id = metadata.get("last_receipt_id")
        if controller._last_receipt_id is not None:
            verdict = controller.verify_receipt(str(controller._last_receipt_id))
            if not verdict.get("valid"):
                raise TurnControlError("stored last receipt/provenance failed Machine verification during restore")

        pending = metadata.get("pending_turn")
        prior_phase = metadata.get("phase")
        if isinstance(pending, Mapping):
            transaction = pending.get("transaction_result") or {}
            arc = pending.get("authorized_realization_context") or {}
            if transaction.get("status") in SUCCESS_TRANSACTION_STATUSES and isinstance(arc, Mapping) and arc:
                authority = controller._authority_snapshot()
                if authority.get("commit_id") != arc.get("commit_id") or authority.get("state_digest") != arc.get("state_digest"):
                    raise TurnControlError("restored Domain authority does not match completed pending transaction")
                controller._current = deepcopy(dict(pending))
                controller._phase = "TRANSACTION_RESOLVED"
                controller._last_recovery_note = "COMPLETED_TRANSACTION_PRESERVED__REALIZATION_REISSUED"
                controller.retry_realization()
                return controller
        if prior_phase != "WAIT_INPUT" or pending:
            controller._last_recovery_note = "STALE_PRETRANSACTION_STAGE_INVALIDATED_ON_RESTORE"
        controller._phase = "WAIT_INPUT"
        controller._current = None
        return controller

    # ---------- Machine-owned helpers ----------

    def _require_phase(self, phase: str) -> None:
        if self._phase != phase:
            raise TurnPhaseError(f"expected phase {phase}, current phase {self._phase}")

    def _require_current(self) -> Dict[str, Any]:
        if self._current is None:
            raise TurnPhaseError("no active controlled turn")
        return self._current

    def _authority_snapshot(self, allow_none: bool = False) -> Optional[Dict[str, Any]]:
        authority = getattr(self.runtime_context, "authority", None)
        if authority is None:
            if allow_none:
                return None
            raise TurnControlError("NO_ACTIVE_AUTHORITY")
        if not isinstance(authority, Mapping) or not authority.get("commit_id") or not authority.get("state_digest"):
            raise TurnControlError("INVALID_RUNTIME_AUTHORITY")
        return deepcopy(dict(authority))

    def _player_authority_context(self, authority: Mapping[str, Any]) -> Dict[str, Any]:
        projector = getattr(self.runtime_context, "player_view_projector", None)
        if projector is None:
            return deepcopy(dict(authority.get("state", {})))
        projected = projector(deepcopy(dict(authority)))
        if not isinstance(projected, Mapping):
            raise TurnControlError("player_view_projector must return a mapping")
        return deepcopy(dict(projected))

    def _episode_binding_identity(self) -> Dict[str, Any]:
        binding = getattr(self.runtime_context, "episode_binding", None)
        if not isinstance(binding, Mapping):
            raise TurnControlError("EPISODE_BINDING_REQUIRED")
        binding_digest = binding.get("binding_digest") or gw.digest({k: v for k, v in binding.items() if k != "binding_digest"})
        identity = {
            "binding_id": binding.get("binding_id"),
            "binding_version": binding.get("binding_version"),
            "binding_digest": binding_digest,
        }
        if not all(identity.values()):
            raise TurnControlError("EPISODE_BINDING_IDENTITY_INCOMPLETE")
        return identity

    def _issue_permit(self, *, stage: str, turn_id: str, request_id: str, base_commit_id: str, base_state_digest: str, input_digest: str) -> Dict[str, Any]:
        permit_id = "PERMIT." + uuid.uuid4().hex
        permit = {
            "permit_id": permit_id,
            "session_id": self.session_id,
            "turn_id": turn_id,
            "stage": stage,
            "request_id": request_id,
            "expected_turn_sequence": self._turn_sequence,
            "base_commit_id": base_commit_id,
            "base_state_digest": base_state_digest,
            "input_digest": input_digest,
            "issued_by_controller": "PLS_MACHINE_TURN_CONTROLLER_V1",
            "status": "ISSUED",
        }
        self._permits[permit_id] = permit
        return deepcopy(permit)

    def _consume_permit(self, permit_id: str, *, stage: str) -> None:
        permit = self._permits.get(permit_id)
        if permit is None:
            raise StaleTurnError("Machine permit not found")
        if permit.get("status") != "ISSUED" or permit.get("stage") != stage:
            raise StaleTurnError("Machine permit is stale, consumed, invalidated, or wrong-stage")
        permit["status"] = "CONSUMED"

    def _validate_host_semantic_response(self, response: Mapping[str, Any]) -> Dict[str, Any]:
        if not isinstance(response, Mapping):
            raise HostResponseError("semantic response must be an object")
        forbidden = AUTHORITY_SENSITIVE_HOST_KEYS.intersection(response.keys())
        if forbidden:
            raise HostResponseError("authority-sensitive Host fields forbidden: " + ",".join(sorted(forbidden)))
        allowed_top = {"request_id", "semantic_units", "actor_ref", "target_refs"}
        extra = set(response.keys()) - allowed_top
        if extra:
            raise HostResponseError("undeclared semantic response fields: " + ",".join(sorted(extra)))
        request_id = response.get("request_id")
        units = response.get("semantic_units")
        if not isinstance(request_id, str) or not request_id:
            raise HostResponseError("request_id required")
        if not isinstance(units, list) or not units:
            raise HostResponseError("semantic_units must be a non-empty list")
        validated_units = []
        allowed_unit = {"semantic_role", "semantic_payload", "visibility", "persistence_intent", "provenance_class", "classification_hints"}
        for index, unit in enumerate(units, start=1):
            if not isinstance(unit, Mapping):
                raise HostResponseError(f"semantic unit {index} must be object")
            bad = AUTHORITY_SENSITIVE_HOST_KEYS.intersection(unit.keys())
            if bad:
                raise HostResponseError("authority-sensitive semantic unit fields forbidden: " + ",".join(sorted(bad)))
            extra_unit = set(unit.keys()) - allowed_unit
            if extra_unit:
                raise HostResponseError("undeclared semantic unit fields: " + ",".join(sorted(extra_unit)))
            role = unit.get("semantic_role")
            payload = unit.get("semantic_payload")
            visibility = unit.get("visibility")
            persistence = unit.get("persistence_intent")
            if role not in ALLOWED_SEMANTIC_ROLES: raise HostResponseError(f"invalid semantic_role at unit {index}")
            if not isinstance(payload, Mapping): raise HostResponseError(f"semantic_payload must be object at unit {index}")
            if visibility not in ALLOWED_VISIBILITY: raise HostResponseError(f"invalid visibility at unit {index}")
            if persistence not in ALLOWED_PERSISTENCE: raise HostResponseError(f"invalid persistence_intent at unit {index}")
            normalized = {
                "semantic_role": role,
                "semantic_payload": deepcopy(dict(payload)),
                "visibility": visibility,
                "persistence_intent": persistence,
            }
            if "provenance_class" in unit: normalized["provenance_class"] = unit.get("provenance_class")
            if "classification_hints" in unit:
                hints = unit.get("classification_hints")
                if not isinstance(hints, list) or not all(isinstance(x, str) for x in hints): raise HostResponseError("classification_hints must be string list")
                normalized["classification_hints"] = list(dict.fromkeys(hints))
            validated_units.append(normalized)
        out = {"request_id": request_id, "semantic_units": validated_units}
        if "actor_ref" in response: out["actor_ref"] = response.get("actor_ref")
        if "target_refs" in response:
            targets = response.get("target_refs")
            if not isinstance(targets, list) or not all(isinstance(x, str) for x in targets): raise HostResponseError("target_refs must be string list")
            out["target_refs"] = list(dict.fromkeys(targets))
        return out

    def _require_authority_matches_base(self, current: Mapping[str, Any]) -> None:
        authority = self._authority_snapshot()
        if authority["commit_id"] != current["base_commit_id"] or authority["state_digest"] != current["base_state_digest"]:
            raise StaleTurnError("runtime authority changed since Machine semantic request was issued")

    def _require_authority_matches_result(self, current: Mapping[str, Any]) -> None:
        authority = self._authority_snapshot()
        arc = current.get("authorized_realization_context") or {}
        if authority["commit_id"] != arc.get("commit_id") or authority["state_digest"] != arc.get("state_digest"):
            raise StaleTurnError("runtime authority changed since realization request was issued")

    def _execute_machine_routed_transaction(self, proposal: Mapping[str, Any]) -> Dict[str, Any]:
        """Execute through a strict Episode resolver; never fall back to Host persistence hints."""
        original_resolver = getattr(self.runtime_context, "binding_resolver", None)
        if original_resolver is None:
            raise TurnControlError("MACHINE_FIRST_V1 requires Episode binding_resolver")

        def strict_resolver(unit: Mapping[str, Any], binding: Mapping[str, Any]):
            decision = original_resolver(unit, binding)
            if decision is None:
                raise gw.UnresolvedBinding(f"MACHINE_FIRST_RESOLVER_MUST_DECIDE:{unit.get('unit_id')}")
            if isinstance(decision, str):
                return decision
            if not isinstance(decision, Mapping):
                raise gw.UnresolvedBinding(f"MACHINE_FIRST_INVALID_RESOLVER_DECISION:{unit.get('unit_id')}")
            if not decision.get("no_state_change") and not decision.get("constructor_id") and not decision.get("reject"):
                raise gw.UnresolvedBinding(f"MACHINE_FIRST_INCOMPLETE_RESOLVER_DECISION:{unit.get('unit_id')}")
            return deepcopy(dict(decision))

        controlled = gw.DomainRuntimeContext(
            episode_binding=self.runtime_context.episode_binding,
            authority=deepcopy(self.runtime_context.authority),
            binding_resolver=strict_resolver,
            semantic_validator=self.runtime_context.semantic_validator,
            apply_constructor=self.runtime_context.apply_constructor,
            validate_state=self.runtime_context.validate_state,
            common_invariant_validator=self.runtime_context.common_invariant_validator,
            episode_invariant_validator=self.runtime_context.episode_invariant_validator,
            player_view_projector=self.runtime_context.player_view_projector,
            no_state_context_projector=self.runtime_context.no_state_context_projector,
            initialization_builder=self.runtime_context.initialization_builder,
            commit_finalizer=self.runtime_context.commit_finalizer,
        )
        result = gw.execute_material_turn(proposal, controlled)
        if result.get("status") in SUCCESS_TRANSACTION_STATUSES:
            self.runtime_context.authority = deepcopy(controlled.authority)
        return result

    def _build_machine_semantic_proposal(self, response: Mapping[str, Any], current: Mapping[str, Any]) -> Dict[str, Any]:
        units = []
        for index, unit in enumerate(response["semantic_units"], start=1):
            normalized = {
                "unit_id": f"{current['turn_id']}.U{index:03d}",
                "semantic_role": unit["semantic_role"],
                "semantic_payload": deepcopy(unit["semantic_payload"]),
                "visibility": unit["visibility"],
                "persistence_intent": unit["persistence_intent"],
            }
            if "provenance_class" in unit: normalized["provenance_class"] = unit.get("provenance_class")
            if "classification_hints" in unit: normalized["classification_hints"] = deepcopy(unit.get("classification_hints") or [])
            units.append(normalized)
        proposal_id = f"SPE.{self.session_id}.{current['turn_id']}"
        proposal = {
            "contract_version": gw.CONTRACT_VERSION,
            "proposal_id": proposal_id,
            "transaction_kind": "MATERIAL_TURN",
            "base_commit_id": current["base_commit_id"],
            "base_state_digest": current["base_state_digest"],
            "source_input_digest": current["source_input_digest"],
            "episode_binding_identity": deepcopy(current["episode_binding_identity"]),
            "actor_ref": response.get("actor_ref") if "actor_ref" in response else current.get("actor_ref"),
            "target_refs": deepcopy(response.get("target_refs") if "target_refs" in response else current.get("target_refs", [])),
            "display_language": current["display_language"],
            "semantic_units": units,
        }
        return gw.validate_semantic_proposal(proposal, require_base=True)

    def _build_machine_arc_v2(self, transaction: Mapping[str, Any], proposal: Mapping[str, Any], current: Mapping[str, Any]) -> Dict[str, Any]:
        authority = self._authority_snapshot()
        transaction_status = transaction.get("status")
        if transaction_status not in SUCCESS_TRANSACTION_STATUSES:
            raise TurnControlError("cannot build ARC from unsuccessful transaction")
        current_context = self._player_authority_context(authority)
        original_arc = transaction.get("authorized_realization_context") or {}
        ephemeral_context = {}
        if transaction_status == "NO_STATE_CHANGE_AUTHORIZED":
            maybe_ephemeral = original_arc.get("player_visible_context")
            if isinstance(maybe_ephemeral, Mapping):
                ephemeral_context = deepcopy(dict(maybe_ephemeral))
        return {
            "contract_version": ARC_CONTRACT_VERSION,
            "authorization_kind": "COMMITTED_STATE" if transaction_status == "COMMITTED" else "NO_STATE_CHANGE",
            "transaction_id": str(transaction.get("transaction_id") or proposal.get("proposal_id")),
            "transaction_status": transaction_status,
            "state_advanced": transaction_status == "COMMITTED",
            "commit_id": authority["commit_id"],
            "state_digest": authority["state_digest"],
            "player_visible_delta": deepcopy(original_arc.get("player_visible_delta") or {}),
            "player_visible_context": current_context,
            "authorized_semantic_context": deepcopy(proposal.get("semantic_units") or []),
            "ephemeral_context": ephemeral_context,
            "actor_view_constraints": deepcopy(original_arc.get("actor_view_constraints") or []),
            "display_language": current["display_language"],
            "provenance_hints": [
                {"source": "PLS_MACHINE_TURN_CONTROLLER_V1", "semantic_request_id": current["semantic_request"]["request_id"]},
                {"source": "COMMON_DOMAIN_TRANSITION_GATEWAY", "transaction_id": transaction.get("transaction_id"), "transaction_status": transaction_status},
            ],
        }

    def _issue_realization_request(self, transaction: Mapping[str, Any], arc: Mapping[str, Any], current: Mapping[str, Any]) -> Dict[str, Any]:
        transaction_digest = canonical_digest(deepcopy(dict(transaction)))
        arc_digest = canonical_digest(deepcopy(dict(arc)))
        request_id = f"RREQ.{self.session_id}.{current['turn_id']}.{arc_digest.split(':',1)[-1][:12]}"
        permit = self._issue_permit(
            stage="REALIZATION_RESPONSE",
            turn_id=current["turn_id"],
            request_id=request_id,
            base_commit_id=arc["commit_id"],
            base_state_digest=arc["state_digest"],
            input_digest=arc_digest,
        )
        return {
            "contract_version": CONTROL_CONTRACT_VERSION,
            "session_id": self.session_id,
            "turn_id": current["turn_id"],
            "request_id": request_id,
            "permit_id": permit["permit_id"],
            "transaction_id": transaction["transaction_id"],
            "transaction_status": transaction["status"],
            "transaction_result_digest": transaction_digest,
            "authorized_realization_context": deepcopy(dict(arc)),
            "authorized_realization_context_digest": arc_digest,
            "current_commit_id": arc["commit_id"],
            "current_state_digest": arc["state_digest"],
            "presentation_contract": deepcopy(self.presentation_contract),
            "display_language": current["display_language"],
        }

    def _format_marker(self, turn_id: str, transaction_status: str, commit_id: str, fingerprint: str) -> str:
        if transaction_status == "NO_STATE_CHANGE_AUTHORIZED":
            return f"⟦PLS·{turn_id}·NOΔ·{commit_id}·R:{fingerprint}⟧"
        return f"⟦PLS·{turn_id}·{commit_id}·R:{fingerprint}⟧"

    def _find_receipt(self, reference: str) -> Optional[Dict[str, Any]]:
        if reference in self._receipts:
            return deepcopy(self._receipts[reference])
        fingerprint = None
        if reference.startswith("R:"):
            fingerprint = reference[2:].strip().upper()
        else:
            match = re.search(r"R:([A-Fa-f0-9]{6,64})", reference)
            if match:
                fingerprint = match.group(1).upper()
        if fingerprint:
            matches = [r for r in self._receipts.values() if str(r.get("fingerprint", "")).upper() == fingerprint]
            if len(matches) == 1:
                return deepcopy(matches[0])
        return None
