from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence
import hashlib, json, secrets

ROOT = Path(__file__).resolve().parents[1]
RUNTIME_ID = "PLS_WELL_RUNTIME_0.2_BUILD_005"
STATE_SCHEMA = "PLS_WELL_AUTHORITATIVE_STATE_0.1"
SAVE_SCHEMA = "PLS_WELL_SAVE_0.1"
BOOT_SCHEMA = "PLS_WELL_BOOT_RECEIPT_0.2"
HOST_SESSION_SCHEMA = "PLS_WELL_HOST_SESSION_0.2"
SETUP_SESSION_SCHEMA = "PLS_WELL_SETUP_SESSION_0.2"

class WellRuntimeError(ValueError): pass
class BootError(WellRuntimeError): pass
class SetupError(WellRuntimeError): pass
class StateError(WellRuntimeError): pass
class UnresolvedBinding(WellRuntimeError): pass
class SaveLoadError(WellRuntimeError): pass

def _load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def _canon(v: Any) -> str:
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def _digest(v: Any) -> str:
    return hashlib.sha256(_canon(v).encode("utf-8")).hexdigest()

def _deepmerge_unique(existing, incoming):
    out=list(existing or [])
    for item in incoming or []:
        if item not in out: out.append(deepcopy(item))
    return out

def _contains_forbidden_future_keys(v: Any, path="$", bad=None):
    if bad is None: bad=[]
    forbidden={"next_source_event","event_queue","quest_queue","canon_repair_target","expected_timeline","reconvergence_target"}
    if isinstance(v,dict):
        for k,x in v.items():
            if str(k).lower() in forbidden: bad.append(f"{path}.{k}")
            _contains_forbidden_future_keys(x,f"{path}.{k}",bad)
    elif isinstance(v,list):
        for i,x in enumerate(v): _contains_forbidden_future_keys(x,f"{path}[{i}]",bad)
    return bad

_BOOT_MARKER = object()


def _read_sha256sums(path: Path):
    out={}
    if not path.exists():
        raise BootError("SHA256SUMS_MISSING")
    for raw in path.read_text(encoding="utf-8").splitlines():
        line=raw.strip()
        if not line:
            continue
        parts=line.split(None,1)
        if len(parts)!=2:
            raise BootError("SHA256SUMS_FORMAT")
        digest, rel=parts
        rel=rel.lstrip("* ")
        out[rel]=digest.lower()
    return out


def verify_package_integrity(root: Path|str=ROOT):
    root=Path(root)
    manifest_path=root/"MANIFEST.json"
    if not manifest_path.exists():
        raise BootError("MANIFEST_MISSING")
    manifest=_load_json(manifest_path)
    sums=_read_sha256sums(root/"SHA256SUMS.txt")
    manifest_hash=hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    if sums.get("MANIFEST.json")!=manifest_hash:
        raise BootError("MANIFEST_HASH_MISMATCH")
    checked=[]
    for item in manifest.get("files",[]):
        rel=item.get("path")
        expected=item.get("sha256")
        if not rel or not expected:
            raise BootError("MANIFEST_FILE_RECORD")
        fp=root/rel
        if not fp.exists() or not fp.is_file():
            raise BootError("PACKAGE_FILE_MISSING:"+str(rel))
        actual=hashlib.sha256(fp.read_bytes()).hexdigest()
        if actual!=expected:
            raise BootError("MANIFEST_FILE_HASH_MISMATCH:"+str(rel))
        if sums.get(rel)!=actual:
            raise BootError("SHA256SUMS_FILE_HASH_MISMATCH:"+str(rel))
        checked.append({"path":rel,"sha256":actual})
    listed={x["path"] for x in checked}
    required={"00_BOOTSTRAP.md","BOOT.py","runtime/well_story_runtime.py"}
    if not required.issubset(listed):
        raise BootError("BOOT_BINDING_FILES_NOT_MANIFESTED")
    fingerprint=_digest({"manifest_sha256":manifest_hash,"files":sorted(checked,key=lambda x:x["path"])})
    return {"manifest":manifest,"manifest_sha256":manifest_hash,"package_fingerprint":fingerprint,"verified_file_count":len(checked)}


class _BootContext:
    def __init__(self, marker, integrity, display_language, boot_session_id=None, setup_session_id=None):
        if marker is not _BOOT_MARKER:
            raise BootError("BOOT_ENTRYPOINT_REQUIRED")
        self.integrity=deepcopy(integrity)
        self.display_language="en" if str(display_language).lower().startswith("en") else "ja"
        self.boot_session_id=boot_session_id or ("BOOT-"+secrets.token_hex(8))
        self.setup_session_id=setup_session_id or ("SETUP-"+secrets.token_hex(8))


class WellStoryRuntime:
    def __init__(self, boot_context=None, root: Path|str=ROOT):
        if not isinstance(boot_context,_BootContext):
            raise BootError("BOOT_ENTRYPOINT_REQUIRED")
        self.root=Path(root)
        self._boot_context=boot_context
        self.episode_manifest=_load_json(self.root/"episode/EPISODE_MANIFEST.json")
        self.rules=_load_json(self.root/"episode/data/PROJECT_RULES.json")
        self.player_policy=_load_json(self.root/"episode/data/PLAYER_CHARACTER_POLICY.json")
        self.world_context=_load_json(self.root/"episode/data/WORLD_CONTEXT_PACKAGE.json")
        self.npc_profiles=_load_json(self.root/"episode/data/NPC_PROFILE_PACKAGE.json")
        self.source_reference=_load_json(self.root/"episode/data/SOURCE_REFERENCE_PACKAGE.json")
        self.opening=_load_json(self.root/"episode/data/OPENING_PRESENTATION_CONTRACT.json")
        self.initialization=_load_json(self.root/"episode/data/INITIALIZATION_POLICY.json")
        self.save_policy=_load_json(self.root/"episode/data/SAVE_LOAD_POLICY.json")
        self.voice=_load_json(self.root/"episode/voice/VOICE_RUNTIME_PACKAGE.json")
        self.display_language=boot_context.display_language
        self.state=None
        self.current_state_hash=None
        self.current_commit_id=None
        self.commit_sequence=0
        self.commit_archive=[]
        self.lineages={"L0001":{"status":"CURRENT","in_world_branch":False,"parent_lineage":None,"fork_commit_id":None}}
        self._setup_confirmation=None
        self.setup_session={
            "schema":SETUP_SESSION_SCHEMA,
            "setup_session_id":boot_context.setup_session_id,
            "stage":"AWAITING_DESCRIPTION",
            "evidence":[],
            "draft_profile":{},
            "field_provenance":{},
            "classification":{},
            "open_material_questions":[],
            "required_resolution":[],
            "confirmation_challenge":None,
            "final_confirmation_evidence":None,
            "confirmed_profile":None,
        }
        self._validate_package()

    def _validate_package(self):
        current=verify_package_integrity(self.root)
        if current["package_fingerprint"]!=self._boot_context.integrity["package_fingerprint"]:
            raise BootError("PACKAGE_CHANGED_AFTER_BOOT")
        if self.source_reference.get("mode")!="REFERENCE_ONLY": raise StateError("SOURCE_REFERENCE_MODE")
        bad=_contains_forbidden_future_keys(self.source_reference)
        if bad: raise StateError("SOURCE_REFERENCE_FORBIDDEN_FUTURE_KEYS:"+",".join(bad))
        if self.episode_manifest.get("runtime")!="runtime/well_story_runtime.py": raise StateError("RUNTIME_BINDING")

    def boot_receipt(self):
        i=self._boot_context.integrity
        core={
            "schema":BOOT_SCHEMA,
            "package_id":i["manifest"].get("package_id"),
            "version":i["manifest"].get("version"),
            "runtime_id":RUNTIME_ID,
            "package_fingerprint":i["package_fingerprint"],
            "manifest_sha256":i["manifest_sha256"],
            "verified_file_count":i["verified_file_count"],
            "boot_session_id":self._boot_context.boot_session_id,
            "setup_session_id":self._boot_context.setup_session_id,
        }
        return {**core,"receipt_digest":_digest(core)}

    def startup_envelope(self):
        if self.setup_session["stage"]!="AWAITING_DESCRIPTION":
            raise SetupError("STARTUP_ALREADY_CONSUMED")
        lang=self.display_language
        return {
            "boot_receipt":self.boot_receipt(),
            "startup":self.opening["startup"][lang],
            "setup_stage":self.setup_session["stage"],
            "next_action":"COLLECT_FREE_CHARACTER_DESCRIPTION",
        }

    def startup_text(self, display_language=None):
        if display_language is not None:
            self.display_language="en" if str(display_language).lower().startswith("en") else "ja"
        return self.startup_envelope()["startup"]

    def character_setup_context(self, display_language=None):
        if display_language is not None:
            self.display_language="en" if str(display_language).lower().startswith("en") else "ja"
        lang=self.display_language
        return {
            "display_language":lang,
            "boot_receipt":self.boot_receipt(),
            "setup_session_id":self.setup_session["setup_session_id"],
            "setup_stage":self.setup_session["stage"],
            "fixed_anchor":{"relationship_to_ralph":"friend"},
            "free_dimensions":deepcopy(self.player_policy["free_dimensions"]),
            "minimum":deepcopy(self.player_policy["setup_minimum"]),
            "adaptive_setup_gate":deepcopy(self.player_policy.get("adaptive_setup_gate",{})),
            "presentation_setup_gate":deepcopy(self.opening.get("adaptive_setup_gate",{}).get(lang,{})),
            "state_change":False,
        }

    def _validate_profile(self, profile: Mapping[str,Any]):
        if not isinstance(profile,Mapping): raise SetupError("PROFILE_NOT_OBJECT")
        for k in ("name_or_address","identity_resolution","nature","presence","communication_with_ralph"):
            if k not in profile: raise SetupError("PROFILE_MISSING:"+k)
        if not isinstance(profile.get("name_or_address"),str) or not profile.get("name_or_address").strip(): raise SetupError("NAME_OR_ADDRESS_EMPTY")
        if profile.get("identity_resolution") not in set(self.player_policy.get("identity_resolution_modes",[])): raise SetupError("IDENTITY_RESOLUTION_MODE")
        if not isinstance(profile.get("presence"),Mapping): raise SetupError("PRESENCE_NOT_OBJECT")
        comm=profile.get("communication_with_ralph")
        if not isinstance(comm,Mapping): raise SetupError("COMMUNICATION_NOT_OBJECT")
        if not isinstance(comm.get("mode"),str) or not comm.get("mode").strip(): raise SetupError("COMMUNICATION_MODE")
        allowed_comm=set(self.player_policy.get("communication_modes",[]))
        if allowed_comm and comm.get("mode") not in allowed_comm: raise SetupError("COMMUNICATION_MODE")
        mode=profile["presence"].get("mode")
        if mode not in set(self.player_policy["presence_modes"]): raise SetupError("PRESENCE_MODE")
        rel=profile.get("relationship_to_ralph","friend")
        if isinstance(rel,str):
            if rel.lower()!="friend": raise SetupError("RALPH_FRIEND_ANCHOR_REQUIRED")
        elif isinstance(rel,Mapping):
            if str(rel.get("kind","")).lower()!="friend": raise SetupError("RALPH_FRIEND_ANCHOR_REQUIRED")
        else: raise SetupError("RALPH_FRIEND_ANCHOR_REQUIRED")
        for k in ("major_capabilities","important_constraints","major_possessions","special_initial_knowledge"):
            if k in profile and not isinstance(profile[k],list): raise SetupError("PROFILE_LIST_REQUIRED:"+k)
        return True


    def _profile_value(self, field):
        return self.setup_session.get("draft_profile",{}).get(field)

    def _has_value(self, field):
        v=self._profile_value(field)
        if v is None: return False
        if isinstance(v,str): return bool(v.strip())
        return True

    def _derive_required_resolution(self, classification, explicit_open):
        req=[]
        def need(x):
            if x not in req: req.append(x)
        for x in ("name_or_address","identity_resolution","nature","presence","communication_with_ralph"):
            if not self._has_value(x): need(x)
        form=str(classification.get("form_class","CUSTOM")).upper()
        if form in {"OBJECT_OR_STRUCTURE","OBJECT_LIKE","STRUCTURAL_SITE"}:
            for x in ("agency_mode","perception_mode","self_movement_mode"):
                if not self._has_value(x): need(x)
        elif form in {"NONPHYSICAL_OR_DISTRIBUTED","NONPHYSICAL","DISTRIBUTED"}:
            if not self._has_value("presence"): need("presence")
        for x in explicit_open or []: need(str(x))
        return req

    def submit_character_draft(self, raw_user_text: str, draft_profile: Mapping[str,Any],
                               field_provenance: Mapping[str,str], classification: Mapping[str,Any],
                               open_material_questions: Optional[Sequence[str]]=None):
        if self.state is not None: raise SetupError("GAME_ALREADY_ACTIVE")
        if self.setup_session["stage"] not in {"AWAITING_DESCRIPTION","CLARIFICATION"}:
            raise SetupError("SETUP_STAGE_NOT_ACCEPTING_DRAFT")
        if not isinstance(raw_user_text,str) or not raw_user_text.strip(): raise SetupError("RAW_USER_TEXT_REQUIRED")
        if not isinstance(draft_profile,Mapping): raise SetupError("DRAFT_PROFILE_OBJECT_REQUIRED")
        if not isinstance(field_provenance,Mapping): raise SetupError("FIELD_PROVENANCE_OBJECT_REQUIRED")
        if not isinstance(classification,Mapping): raise SetupError("CLASSIFICATION_OBJECT_REQUIRED")
        allowed_prov={"USER_EXPLICIT","USER_CONFIRMED","AI_INTERPRETATION","AUTHORIZED_OPERATIONAL_DEFAULT"}
        for k,v in draft_profile.items():
            if k not in field_provenance: raise SetupError("FIELD_PROVENANCE_REQUIRED:"+str(k))
            if field_provenance[k] not in allowed_prov: raise SetupError("FIELD_PROVENANCE_INVALID:"+str(k))
        ev={"turn_index":len(self.setup_session["evidence"])+1,"raw_text":raw_user_text,
            "raw_text_sha256":hashlib.sha256(raw_user_text.encode("utf-8")).hexdigest(),
            "draft_digest":_digest(draft_profile),"classification_digest":_digest(classification)}
        self.setup_session["evidence"].append(ev)
        self.setup_session["draft_profile"]=deepcopy(dict(draft_profile))
        self.setup_session["field_provenance"]=deepcopy(dict(field_provenance))
        self.setup_session["classification"]=deepcopy(dict(classification))
        explicit_open=list(open_material_questions or [])
        self.setup_session["open_material_questions"]=explicit_open
        req=self._derive_required_resolution(classification,explicit_open)
        self.setup_session["required_resolution"]=req
        self.setup_session["stage"]="CLARIFICATION" if req else "READY_FOR_CONFIRMATION"
        return {
            "status":"NEEDS_CLARIFICATION" if req else "READY_FOR_CONFIRMATION",
            "setup_session_id":self.setup_session["setup_session_id"],
            "required_resolution":deepcopy(req),
            "draft_profile":deepcopy(self.setup_session["draft_profile"]),
            "classification":deepcopy(self.setup_session["classification"]),
            "state_change":False,
        }

    def prepare_final_confirmation(self):
        if self.setup_session["stage"]!="READY_FOR_CONFIRMATION":
            raise SetupError("SETUP_NOT_READY_FOR_CONFIRMATION")
        profile=deepcopy(self.setup_session["draft_profile"])
        self._validate_profile(profile)
        classification=self.setup_session["classification"]
        challenge_core={
            "setup_session_id":self.setup_session["setup_session_id"],
            "profile_digest":_digest(profile),
            "evidence_digest":_digest(self.setup_session["evidence"]),
            "classification_digest":_digest(classification),
            "nonce":secrets.token_hex(6),
        }
        challenge={"challenge_id":"CONFIRM-"+_digest(challenge_core)[:16],**challenge_core}
        self.setup_session["confirmation_challenge"]=challenge
        self.setup_session["stage"]="AWAITING_FINAL_CONFIRMATION"
        return {
            "status":"AWAITING_FINAL_CONFIRMATION",
            "setup_session_id":self.setup_session["setup_session_id"],
            "challenge_id":challenge["challenge_id"],
            "confirmed_candidate_profile":profile,
            "material_world_mismatch":classification.get("material_world_mismatch") is True,
            "low_agency":classification.get("low_agency") is True,
            "state_change":False,
        }

    def accept_final_confirmation(self, raw_user_text: str, interpreted_intent: str, challenge_id: str,
                                  divergence_confirmed=False, low_agency_confirmed=False):
        if self.setup_session["stage"]!="AWAITING_FINAL_CONFIRMATION":
            raise SetupError("FINAL_CONFIRMATION_NOT_EXPECTED")
        ch=self.setup_session.get("confirmation_challenge") or {}
        if challenge_id!=ch.get("challenge_id"): raise SetupError("CONFIRMATION_CHALLENGE_MISMATCH")
        if not isinstance(raw_user_text,str) or not raw_user_text.strip(): raise SetupError("RAW_CONFIRMATION_TEXT_REQUIRED")
        if str(interpreted_intent).upper()!="CONFIRM": raise SetupError("USER_DID_NOT_CONFIRM")
        c=self.setup_session["classification"]
        if c.get("material_world_mismatch") is True and divergence_confirmed is not True:
            raise SetupError("DIVERGENCE_CONFIRMATION_REQUIRED")
        if c.get("low_agency") is True and low_agency_confirmed is not True:
            raise SetupError("LOW_AGENCY_CONFIRMATION_REQUIRED")
        profile=deepcopy(self.setup_session["draft_profile"])
        self._validate_profile(profile)
        evidence={
            "raw_text":raw_user_text,
            "raw_text_sha256":hashlib.sha256(raw_user_text.encode("utf-8")).hexdigest(),
            "interpreted_intent":"CONFIRM",
            "challenge_id":challenge_id,
            "profile_digest":_digest(profile),
        }
        permit_core={
            "boot_session_id":self._boot_context.boot_session_id,
            "setup_session_id":self.setup_session["setup_session_id"],
            "challenge_id":challenge_id,
            "profile_digest":_digest(profile),
            "confirmation_evidence_digest":_digest(evidence),
        }
        permit={"schema":"PLS_WELL_SETUP_PERMIT_0.2","permit_id":"PERMIT-"+_digest(permit_core)[:16],**permit_core}
        self.setup_session["final_confirmation_evidence"]=evidence
        self.setup_session["confirmed_profile"]=profile
        self.setup_session["stage"]="CONFIRMED"
        self._setup_confirmation=deepcopy(permit)
        return permit

    def confirm_character_setup(self, *args, **kwargs):
        raise SetupError("LEGACY_SETUP_API_DISABLED_USE_SETUP_SESSION_STATE_MACHINE")

    def _verify_setup_permit(self, permit):
        if self.setup_session["stage"]!="CONFIRMED": raise SetupError("SETUP_NOT_CONFIRMED")
        if not isinstance(permit,Mapping) or permit.get("schema")!="PLS_WELL_SETUP_PERMIT_0.2":
            raise SetupError("SETUP_PERMIT_REQUIRED")
        if self._setup_confirmation is None or dict(permit)!=self._setup_confirmation:
            raise SetupError("SETUP_PERMIT_NOT_ISSUED_BY_RUNTIME")
        if permit.get("boot_session_id")!=self._boot_context.boot_session_id:
            raise SetupError("SETUP_PERMIT_WRONG_BOOT_SESSION")
        if permit.get("setup_session_id")!=self.setup_session["setup_session_id"]:
            raise SetupError("SETUP_PERMIT_WRONG_SETUP_SESSION")
        if permit.get("profile_digest")!=_digest(self.setup_session["confirmed_profile"]):
            raise SetupError("SETUP_PERMIT_PROFILE_MISMATCH")
        return True

    def new_game(self, bridge_history: Mapping[str,Any], setup_permit: Mapping[str,Any], display_language=None):
        if self.state is not None: raise StateError("ACTIVE_GAME_EXISTS")
        self._verify_setup_permit(setup_permit)
        p=deepcopy(self.setup_session["confirmed_profile"])
        self._validate_profile(p)
        if not isinstance(bridge_history,Mapping): raise SetupError("BRIDGE_HISTORY_REQUIRED")
        for k in ("summary","ralph_friendship_basis","necessary_world_differences","npc_awareness"):
            if k not in bridge_history: raise SetupError("BRIDGE_MISSING:"+k)
        if not isinstance(bridge_history["necessary_world_differences"],list): raise SetupError("BRIDGE_WORLD_DIFF_LIST")
        if not isinstance(bridge_history["npc_awareness"],Mapping): raise SetupError("BRIDGE_NPC_AWARENESS")
        if display_language is not None:
            self.display_language="en" if str(display_language).lower().startswith("en") else "ja"
        p["relationship_to_ralph"]="friend"
        ralph_knowledge=["three elder brothers have just departed","father requested Ralph remain in Upmeads","Ralph knows the player character according to the confirmed friendship bridge"]
        actor_states={
            "RALPH":{
                "alive":True,"age":21,"location":{"ref":"UPMEADS_WANT_WAY_DEPARTURE_AREA","certainty":"SOURCE_CONTEXTUAL"},
                "conditions":["dissatisfied at being required to remain"],
                "goals":["cares for family and Upmeads","wants to see the wider world"],
                "knowledge":{"known":ralph_knowledge,"beliefs":[],"private":[]},
                "player_awareness":deepcopy(bridge_history["npc_awareness"].get("RALPH",{})),
            },
            "KING_PETER":{
                "alive":True,"location":{"ref":"UPMEADS_WANT_WAY_DEPARTURE_AREA","certainty":"SOURCE_CONTEXTUAL"},
                "conditions":[],"goals":["support family and Upmeads","keep one son near home for family and defense"],
                "knowledge":{"known":["three elder sons have departed","Ralph drew the lot to remain"],"beliefs":[],"private":[]},
                "player_awareness":deepcopy(bridge_history["npc_awareness"].get("KING_PETER",{})),
            },
            "NICHOLAS_LONGSHANKS":{
                "alive":True,"location":{"ref":"UPMEADS_DEPARTURE_AREA_OR_HOMEWARD_ROUTE","certainty":"SOURCE_CONTEXTUAL"},
                "conditions":[],"goals":["serve King Peter's house"],
                "knowledge":{"known":["three elder sons have departed","Ralph remains"],"beliefs":[],"private":[]},
                "player_awareness":deepcopy(bridge_history["npc_awareness"].get("NICHOLAS_LONGSHANKS",{})),
            }
        }
        state={
            "schema":STATE_SCHEMA,
            "formal_start":{"anchor":"AFTER_BOOK_I_CHAPTER_1_THREE_BROTHERS_DEPART","description":"Hot June afternoon immediately after the three elder brothers depart"},
            "world_time":{"anchor":"AFTER_BOOK_I_CHAPTER_1_THREE_BROTHERS_DEPART","elapsed_seconds":0},
            "player":{
                "profile":p,"conditions":[],"knowledge":deepcopy(p.get("special_initial_knowledge",[])),
                "possessions":deepcopy(p.get("major_possessions",[])),"capability_semantics":{"temporal_rules":deepcopy(p.get("temporal_rules"))},
                "setup_authority":{
                    "status":"USER_CONFIRMED",
                    "profile_digest":setup_permit["profile_digest"],
                    "confirmation_evidence_digest":setup_permit["confirmation_evidence_digest"],
                    "setup_session_id":setup_permit["setup_session_id"],
                },
            },
            "actors":actor_states,
            "relationships":[{"a":"PLAYER","b":"RALPH","kind":"friend","state":"active","basis":bridge_history["ralph_friendship_basis"]}],
            "world":{
                "source_baseline":deepcopy(self.initialization["source_baseline_at_t0"]),
                "prestart_bridge_summary":bridge_history["summary"],
                "prestart_world_differences":deepcopy(bridge_history["necessary_world_differences"]),
                "generated_facts":[],"locations":{},"objects":{},
            },
            "active_processes":[],"unresolved":[],
            "source_future_reference_mode":"REFERENCE_ONLY",
            "temporal":{"semantics":"LINEAR_DEFAULT" if not p.get("temporal_rules") else p.get("temporal_rules",{}).get("mode","UNRESOLVED"),"current_lineage_id":"L0001","in_world_branches":[]},
        }
        self._validate_state(state)
        self.state=state
        self.current_state_hash=_digest(state)
        self.commit_sequence=0; self.commit_archive=[]; self.current_commit_id=None
        self.lineages={"L0001":{"status":"CURRENT","in_world_branch":False,"parent_lineage":None,"fork_commit_id":None}}
        self._record_commit(kind="GENESIS",before_hash=None,summary="Formal start committed",effect_digest=_digest({"profile":p,"bridge":bridge_history}))
        self.setup_session["stage"]="GAME_ACTIVE"
        self._setup_confirmation=None
        return {"status":"COMMITTED","commit_id":self.current_commit_id,"state_hash":self.current_state_hash,"player_view":self.status_view(),"boot_receipt":self.boot_receipt()}

    def export_host_checkpoint(self):
        return {
            "schema":HOST_SESSION_SCHEMA,
            "package_fingerprint":self._boot_context.integrity["package_fingerprint"],
            "display_language":self.display_language,
            "boot_receipt":self.boot_receipt(),
            "setup_session":deepcopy(self.setup_session),
            "setup_permit":deepcopy(self._setup_confirmation),
            "state":deepcopy(self.state),
            "current_state_hash":self.current_state_hash,
            "current_commit_id":self.current_commit_id,
            "commit_sequence":self.commit_sequence,
            "commit_archive":deepcopy(self.commit_archive),
            "lineages":deepcopy(self.lineages),
        }

    def write_host_checkpoint(self, path: Path|str):
        path=Path(path)
        payload=self.export_host_checkpoint()
        core=deepcopy(payload)
        payload["checkpoint_digest"]=_digest(core)
        path.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        return path

    def _validate_actor_state(self, actor_id, actor):
        if not isinstance(actor_id,str) or not actor_id: raise StateError("ACTOR_ID")
        if not isinstance(actor,Mapping): raise StateError("ACTOR_STATE")
        if not isinstance(actor.get("alive"),bool): raise StateError("ACTOR_ALIVE_TYPE")
        if not isinstance(actor.get("location"),Mapping): raise StateError("ACTOR_LOCATION_TYPE")
        for k in ("conditions","goals"):
            if not isinstance(actor.get(k,[]),list): raise StateError("ACTOR_LIST:"+k)
        know=actor.get("knowledge",{})
        if not isinstance(know,Mapping): raise StateError("ACTOR_KNOWLEDGE_TYPE")
        for channel in ("known","beliefs","private"):
            if not isinstance(know.get(channel,[]),list): raise StateError("ACTOR_KNOWLEDGE_CHANNEL:"+channel)
        if not isinstance(actor.get("player_awareness",{}),Mapping): raise StateError("ACTOR_PLAYER_AWARENESS")
        return True

    def _validate_state(self,state):
        if not isinstance(state,dict) or state.get("schema")!=STATE_SCHEMA: raise StateError("STATE_SCHEMA")
        for k in ("formal_start","world_time","player","actors","relationships","world","active_processes","unresolved","temporal"):
            if k not in state: raise StateError("STATE_MISSING:"+k)
        if state.get("source_future_reference_mode")!="REFERENCE_ONLY": raise StateError("SOURCE_FUTURE_MODE")
        bad=_contains_forbidden_future_keys(state)
        if bad: raise StateError("FORBIDDEN_FUTURE_KEY:"+",".join(bad))
        self._validate_profile(state["player"]["profile"])
        if not isinstance(state.get("actors"),Mapping): raise StateError("ACTORS_TYPE")
        for actor_id,actor in state["actors"].items(): self._validate_actor_state(actor_id,actor)
        if not isinstance(state["world_time"].get("elapsed_seconds"),int): raise StateError("WORLD_TIME_TYPE")
        return True

    def _record_commit(self,kind,before_hash,summary,effect_digest):
        self._validate_state(self.state)
        after_hash=_digest(self.state)
        self.commit_sequence+=1
        lineage=self.state["temporal"]["current_lineage_id"]
        core={"sequence":self.commit_sequence,"parent_commit_id":self.current_commit_id,"lineage_id":lineage,
              "before_hash":before_hash,"after_hash":after_hash,"fictional_elapsed_seconds":self.state["world_time"]["elapsed_seconds"],
              "kind":kind,"effect_digest":effect_digest,"summary":summary}
        cid=f"C{self.commit_sequence:06d}-"+_digest(core)[:12]
        rec={"commit_id":cid,**core,"snapshot":deepcopy(self.state)}
        self.commit_archive.append(rec)
        self.current_commit_id=cid; self.current_state_hash=after_hash
        return rec

    def switch_language(self,display_language):
        if self.state is None: raise StateError("NO_ACTIVE_GAME")
        before=self.current_state_hash
        self.display_language="en" if str(display_language).lower().startswith("en") else "ja"
        if _digest(self.state)!=before: raise StateError("LANGUAGE_CHANGED_WORLD_STATE")
        return {"status":"OK","display_language":self.display_language,"state_hash":before}

    def status_view(self):
        if self.state is None: raise StateError("NO_ACTIVE_GAME")
        p=self.state["player"]
        rel=[]
        for r in self.state["relationships"]:
            if "PLAYER" in (r.get("a"),r.get("b")): rel.append({k:deepcopy(v) for k,v in r.items() if k not in {"private"}})
        visible_processes=[]
        for x in self.state["active_processes"]:
            if x.get("player_visible") is True: visible_processes.append(deepcopy(x))
        return {
            "time":{"anchor":self.state["world_time"]["anchor"],"elapsed_seconds":self.state["world_time"]["elapsed_seconds"]},
            "presence":deepcopy(p["profile"]["presence"]),"conditions":deepcopy(p.get("conditions",[])),
            "possessions":deepcopy(p.get("possessions",[])),"known_relationships":rel,
            "player_knowledge":deepcopy(p.get("knowledge",[])),"visible_active_processes":visible_processes,
        }

    def _find_relationship(self,a,b,kind=None,state=None):
        target=self.state if state is None else state
        if target is None: return None
        for r in target["relationships"]:
            if r.get("a")==a and r.get("b")==b and (kind is None or r.get("kind")==kind): return r
            if r.get("a")==b and r.get("b")==a and (kind is None or r.get("kind")==kind): return r
        return None

    def commit_effects(self,effects: Sequence[Mapping[str,Any]], summary: str):
        if self.state is None: raise StateError("NO_ACTIVE_GAME")
        if not isinstance(effects,Sequence) or isinstance(effects,(str,bytes)): raise StateError("EFFECTS_LIST_REQUIRED")
        before_hash=self.current_state_hash
        candidate=deepcopy(self.state)
        for e in effects:
            self._apply_effect(candidate,e)
        self._validate_state(candidate)
        self.state=candidate
        return {"status":"COMMITTED",**{k:v for k,v in self._record_commit("MATERIAL_TURN",before_hash,summary,_digest(list(effects))).items() if k!="snapshot"},"player_view":self.status_view()}

    def _apply_effect(self,s,e):
        if not isinstance(e,Mapping): raise StateError("EFFECT_NOT_OBJECT")
        kind=e.get("kind")
        if kind=="TIME_ADVANCE":
            sec=e.get("seconds")
            if not isinstance(sec,int) or sec<0: raise StateError("TIME_ADVANCE_SECONDS")
            s["world_time"]["elapsed_seconds"]+=sec
        elif kind=="PLAYER_PRESENCE_SET":
            pres=e.get("presence")
            if not isinstance(pres,Mapping) or pres.get("mode") not in set(self.player_policy["presence_modes"]): raise StateError("PLAYER_PRESENCE")
            s["player"]["profile"]["presence"]=deepcopy(dict(pres))
        elif kind=="PLAYER_CONDITION_ADD":
            s["player"]["conditions"]=_deepmerge_unique(s["player"].get("conditions",[]),[e.get("condition")])
        elif kind=="PLAYER_CONDITION_REMOVE":
            s["player"]["conditions"]=[x for x in s["player"].get("conditions",[]) if x!=e.get("condition")]
        elif kind=="PLAYER_KNOWLEDGE_ADD":
            item=e.get("knowledge")
            if item is None: raise StateError("PLAYER_KNOWLEDGE")
            s["player"]["knowledge"]=_deepmerge_unique(s["player"].get("knowledge",[]),[item])
        elif kind=="PLAYER_POSSESSION_ADD":
            item=e.get("item")
            if item is None: raise StateError("PLAYER_POSSESSION")
            s["player"]["possessions"]=_deepmerge_unique(s["player"].get("possessions",[]),[item])
        elif kind=="PLAYER_POSSESSION_REMOVE":
            s["player"]["possessions"]=[x for x in s["player"].get("possessions",[]) if x!=e.get("item")]
        elif kind=="PLAYER_PROFILE_CAUSAL_CHANGE":
            if e.get("authorized_by_player_or_world_cause") is not True: raise StateError("PLAYER_PROFILE_CHANGE_AUTHORITY")
            patch=e.get("patch")
            if not isinstance(patch,Mapping): raise StateError("PLAYER_PROFILE_PATCH")
            forbidden={"relationship_to_ralph"}
            if forbidden & set(patch): raise StateError("FIXED_ANCHOR_DIRECT_PATCH")
            s["player"]["profile"].update(deepcopy(dict(patch)))
            self._validate_profile(s["player"]["profile"])
        elif kind=="ACTOR_ADD":
            aid=e.get("actor_id"); actor=e.get("actor")
            if not isinstance(aid,str) or not aid or aid in s["actors"]: raise StateError("ACTOR_ADD_ID")
            if not isinstance(actor,Mapping): raise StateError("ACTOR_ADD_STATE")
            a=deepcopy(dict(actor))
            a.setdefault("alive",True)
            a.setdefault("location",{"ref":"UNRESOLVED","certainty":"GAME_ADDED_SESSION"})
            a.setdefault("conditions",[])
            a.setdefault("goals",[])
            a.setdefault("knowledge",{"known":[],"beliefs":[],"private":[]})
            a.setdefault("player_awareness",{})
            a.setdefault("provenance","GAME_ADDED_SESSION")
            self._validate_actor_state(aid,a)
            s["actors"][aid]=a
        elif kind=="ACTOR_LOCATION_SET":
            aid=e.get("actor_id"); loc=e.get("location")
            if aid not in s["actors"] or not isinstance(loc,Mapping): raise StateError("ACTOR_LOCATION")
            s["actors"][aid]["location"]=deepcopy(dict(loc))
        elif kind=="ACTOR_CONDITION_ADD":
            aid=e.get("actor_id"); val=e.get("condition")
            if aid not in s["actors"]: raise StateError("ACTOR_ID")
            s["actors"][aid]["conditions"]=_deepmerge_unique(s["actors"][aid].get("conditions",[]),[val])
        elif kind=="ACTOR_CONDITION_REMOVE":
            aid=e.get("actor_id"); val=e.get("condition")
            if aid not in s["actors"]: raise StateError("ACTOR_ID")
            s["actors"][aid]["conditions"]=[x for x in s["actors"][aid].get("conditions",[]) if x!=val]
        elif kind=="ACTOR_GOAL_ADD":
            aid=e.get("actor_id"); val=e.get("goal")
            if aid not in s["actors"] or val is None: raise StateError("ACTOR_GOAL")
            s["actors"][aid]["goals"]=_deepmerge_unique(s["actors"][aid].get("goals",[]),[val])
        elif kind=="ACTOR_GOAL_REMOVE":
            aid=e.get("actor_id"); val=e.get("goal")
            if aid not in s["actors"]: raise StateError("ACTOR_ID")
            s["actors"][aid]["goals"]=[x for x in s["actors"][aid].get("goals",[]) if x!=val]
        elif kind=="ACTOR_ALIVE_SET":
            aid=e.get("actor_id")
            if aid not in s["actors"] or not isinstance(e.get("alive"),bool): raise StateError("ACTOR_ALIVE")
            s["actors"][aid]["alive"]=e["alive"]
        elif kind=="ACTOR_KNOWLEDGE_ADD":
            aid=e.get("actor_id"); info=e.get("knowledge"); channel=e.get("channel","known")
            if aid not in s["actors"] or channel not in {"known","beliefs","private"}: raise StateError("ACTOR_KNOWLEDGE")
            s["actors"][aid]["knowledge"][channel]=_deepmerge_unique(s["actors"][aid]["knowledge"].get(channel,[]),[info])
        elif kind=="RELATIONSHIP_SET":
            a=e.get("a"); b=e.get("b"); relkind=e.get("relationship_kind"); state=e.get("state")
            if not all(isinstance(x,str) and x for x in (a,b,relkind,state)): raise StateError("RELATIONSHIP_FIELDS")
            r=self._find_relationship(a,b,relkind,state=s)
            if r is None: s["relationships"].append({"a":a,"b":b,"kind":relkind,"state":state,"basis":e.get("basis","session_causality")})
            else: r["state"]=state; r["basis"]=e.get("basis",r.get("basis"))
        elif kind=="GENERATED_FACT_ADD":
            fact=e.get("fact")
            if not isinstance(fact,Mapping) or not fact.get("id") or not fact.get("statement"): raise StateError("GENERATED_FACT")
            if fact.get("provenance") not in {None,"GAME_ADDED_SESSION"}: raise StateError("GENERATED_FACT_PROVENANCE")
            f=deepcopy(dict(fact)); f["provenance"]="GAME_ADDED_SESSION"
            if not any(x.get("id")==f["id"] for x in s["world"]["generated_facts"]): s["world"]["generated_facts"].append(f)
        elif kind=="LOCATION_STATE_SET":
            lid=e.get("location_id"); value=e.get("state")
            if not isinstance(lid,str) or not isinstance(value,Mapping): raise StateError("LOCATION_STATE")
            s["world"]["locations"][lid]=deepcopy(dict(value))
        elif kind=="OBJECT_STATE_SET":
            oid=e.get("object_id"); value=e.get("state")
            if not isinstance(oid,str) or not isinstance(value,Mapping): raise StateError("OBJECT_STATE")
            s["world"]["objects"][oid]=deepcopy(dict(value))
        elif kind=="PROCESS_START":
            proc=e.get("process")
            if not isinstance(proc,Mapping) or not proc.get("id"): raise StateError("PROCESS_START")
            if any(x.get("id")==proc.get("id") for x in s["active_processes"]): raise StateError("PROCESS_DUPLICATE")
            s["active_processes"].append(deepcopy(dict(proc)))
        elif kind=="PROCESS_UPDATE":
            pid=e.get("process_id"); patch=e.get("patch")
            if not isinstance(patch,Mapping): raise StateError("PROCESS_PATCH")
            proc=next((x for x in s["active_processes"] if x.get("id")==pid),None)
            if proc is None: raise StateError("PROCESS_NOT_FOUND")
            proc.update(deepcopy(dict(patch)))
        elif kind=="PROCESS_RESOLVE":
            pid=e.get("process_id")
            proc=next((x for x in s["active_processes"] if x.get("id")==pid),None)
            if proc is None: raise StateError("PROCESS_NOT_FOUND")
            s["active_processes"]=[x for x in s["active_processes"] if x.get("id")!=pid]
        elif kind=="UNRESOLVED_ADD":
            u=e.get("item")
            if not isinstance(u,Mapping) or not u.get("id"): raise StateError("UNRESOLVED_ITEM")
            if not any(x.get("id")==u["id"] for x in s["unresolved"]): s["unresolved"].append(deepcopy(dict(u)))
        elif kind=="UNRESOLVED_RESOLVE":
            uid=e.get("id"); resolution=e.get("resolution")
            item=next((x for x in s["unresolved"] if x.get("id")==uid),None)
            if item is None: raise StateError("UNRESOLVED_NOT_FOUND")
            s["unresolved"]=[x for x in s["unresolved"] if x.get("id")!=uid]
            s["world"]["generated_facts"].append({"id":"RESOLVED-"+uid,"statement":resolution,"provenance":"GAME_ADDED_SESSION","from_unresolved":uid})
        elif kind=="TEMPORAL_RULES_CONFIRM":
            rules=e.get("rules")
            if not isinstance(rules,Mapping): raise StateError("TEMPORAL_RULES")
            mode=rules.get("mode")
            if mode not in {"SINGLE_REWRITE","BRANCHING","SELF_CONSISTENT"}: raise StateError("TEMPORAL_MODE")
            if rules.get("memory_retention") not in {"PLAYER_RETAINS","NONE","CUSTOM"}: raise StateError("TEMPORAL_MEMORY_RULE")
            if rules.get("carry_mode") not in {"CURRENT_TRAVELER_STATE","TARGET_ERA_PLAYER_STATE","CUSTOM"}: raise StateError("TEMPORAL_CARRY_RULE")
            s["player"]["capability_semantics"]["temporal_rules"]=deepcopy(dict(rules))
            s["temporal"]["semantics"]=mode
        else:
            raise StateError("UNKNOWN_EFFECT_KIND:"+str(kind))

    def temporal_rebase(self,target_commit_id: str, summary="Temporal rebase"):
        if self.state is None: raise StateError("NO_ACTIVE_GAME")
        rules=self.state["player"].get("capability_semantics",{}).get("temporal_rules")
        if not isinstance(rules,Mapping) or rules.get("mode") not in {"SINGLE_REWRITE","BRANCHING","SELF_CONSISTENT"}:
            raise UnresolvedBinding("TEMPORAL_SEMANTICS_UNRESOLVED")
        target=next((x for x in self.commit_archive if x.get("commit_id")==target_commit_id),None)
        if target is None: raise StateError("TARGET_COMMIT_NOT_FOUND")
        if rules["mode"]=="SELF_CONSISTENT":
            raise UnresolvedBinding("SELF_CONSISTENT_REBASE_REQUIRES_HOST_CAUSAL_RESOLUTION")
        current_player=deepcopy(self.state["player"])
        current_lineage=self.state["temporal"]["current_lineage_id"]
        target_state=deepcopy(target["snapshot"])
        new_lineage=f"L{len(self.lineages)+1:04d}"
        if rules["carry_mode"]=="CURRENT_TRAVELER_STATE":
            target_state["player"]=current_player
        elif rules["carry_mode"]=="CUSTOM":
            raise UnresolvedBinding("CUSTOM_TEMPORAL_CARRY_REQUIRES_EXPLICIT_HOST_CONSTRUCTION")
        if rules["memory_retention"]=="PLAYER_RETAINS" and rules["carry_mode"]!="CURRENT_TRAVELER_STATE":
            target_state["player"]["knowledge"]=_deepmerge_unique(target_state["player"].get("knowledge",[]),current_player.get("knowledge",[]))
        elif rules["memory_retention"]=="CUSTOM":
            raise UnresolvedBinding("CUSTOM_TEMPORAL_MEMORY_REQUIRES_EXPLICIT_HOST_CONSTRUCTION")
        if rules["mode"]=="SINGLE_REWRITE":
            self.lineages[current_lineage]["status"]="SUPERSEDED_RUNTIME_EVIDENCE"
            self.lineages[current_lineage]["in_world_branch"]=False
        else:
            self.lineages[current_lineage]["status"]="IN_WORLD_BRANCH"
            self.lineages[current_lineage]["in_world_branch"]=True
            target_state["temporal"].setdefault("in_world_branches",[])
            if current_lineage not in target_state["temporal"]["in_world_branches"]: target_state["temporal"]["in_world_branches"].append(current_lineage)
        self.lineages[new_lineage]={"status":"CURRENT","in_world_branch":rules["mode"]=="BRANCHING","parent_lineage":target.get("lineage_id"),"fork_commit_id":target_commit_id}
        target_state["temporal"]["current_lineage_id"]=new_lineage
        target_state["temporal"]["semantics"]=rules["mode"]
        before_hash=self.current_state_hash
        self.state=target_state
        self._validate_state(self.state)
        return {"status":"COMMITTED",**{k:v for k,v in self._record_commit("TEMPORAL_REBASE",before_hash,summary,_digest({"target":target_commit_id,"rules":rules})).items() if k!="snapshot"},"player_view":self.status_view()}

    def export_save(self):
        if self.state is None: raise SaveLoadError("NO_ACTIVE_GAME")
        payload={
            "schema":SAVE_SCHEMA,"runtime_id":RUNTIME_ID,"episode_id":self.episode_manifest["episode_id"],
            "episode_version":self.episode_manifest["version"],"authoritative_state":deepcopy(self.state),
            "state_hash":self.current_state_hash,"current_commit_id":self.current_commit_id,"commit_sequence":self.commit_sequence,
            "commit_archive":deepcopy(self.commit_archive),"lineages":deepcopy(self.lineages),
            "presentation":{"display_language":self.display_language},
        }
        core=deepcopy(payload); core["save_digest"]=""
        payload["save_digest"]=_digest(core)
        return payload

    def import_save(self,payload: Mapping[str,Any]):
        if not isinstance(payload,Mapping) or payload.get("schema")!=SAVE_SCHEMA: raise SaveLoadError("SAVE_SCHEMA")
        if payload.get("runtime_id")!=RUNTIME_ID or payload.get("episode_id")!=self.episode_manifest["episode_id"]: raise SaveLoadError("SAVE_RUNTIME_IDENTITY")
        core=deepcopy(dict(payload)); supplied=core.pop("save_digest",None); core["save_digest"]=""
        if supplied!=_digest(core): raise SaveLoadError("SAVE_DIGEST")
        state=deepcopy(payload.get("authoritative_state"))
        self._validate_state(state)
        if _digest(state)!=payload.get("state_hash"): raise SaveLoadError("STATE_HASH")
        archive=deepcopy(payload.get("commit_archive"))
        if not isinstance(archive,list) or not archive: raise SaveLoadError("COMMIT_ARCHIVE")
        prev=None
        for i,rec in enumerate(archive,1):
            if rec.get("sequence")!=i or rec.get("parent_commit_id")!=prev: raise SaveLoadError("COMMIT_CHAIN")
            snap=rec.get("snapshot")
            self._validate_state(snap)
            if _digest(snap)!=rec.get("after_hash"): raise SaveLoadError("COMMIT_SNAPSHOT_HASH")
            core_rec={k:deepcopy(v) for k,v in rec.items() if k not in {"commit_id","snapshot"}}
            expected=f"C{i:06d}-"+_digest(core_rec)[:12]
            if rec.get("commit_id")!=expected: raise SaveLoadError("COMMIT_ID")
            prev=rec.get("commit_id")
        if payload.get("current_commit_id")!=archive[-1].get("commit_id"): raise SaveLoadError("CURRENT_COMMIT")
        if payload.get("commit_sequence")!=len(archive): raise SaveLoadError("COMMIT_SEQUENCE")
        self.state=state; self.current_state_hash=payload["state_hash"]; self.current_commit_id=payload["current_commit_id"]
        self.commit_sequence=payload["commit_sequence"]; self.commit_archive=archive
        self.lineages=deepcopy(payload.get("lineages") or {})
        self.display_language=(payload.get("presentation") or {}).get("display_language","ja")
        return {"status":"RESTORED","commit_id":self.current_commit_id,"state_hash":self.current_state_hash,"player_view":self.status_view()}

    def write_save_file(self,path: Path|str):
        path=Path(path); path.write_text(json.dumps(self.export_save(),ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); return path

    def load_save_file(self,path: Path|str):
        return self.import_save(json.loads(Path(path).read_text(encoding="utf-8")))

def boot_player(root: Path|str=ROOT, display_language="ja"):
    integrity=verify_package_integrity(root)
    ctx=_BootContext(_BOOT_MARKER,integrity,display_language)
    rt=WellStoryRuntime(ctx,root=root)
    return rt,rt.startup_envelope()


def restore_host_checkpoint(path: Path|str, root: Path|str=ROOT):
    payload=json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema")!=HOST_SESSION_SCHEMA: raise BootError("HOST_SESSION_SCHEMA")
    supplied=payload.pop("checkpoint_digest",None)
    if supplied!=_digest(payload): raise BootError("HOST_SESSION_DIGEST")
    integrity=verify_package_integrity(root)
    if payload.get("package_fingerprint")!=integrity["package_fingerprint"]: raise BootError("HOST_SESSION_PACKAGE_MISMATCH")
    receipt=payload.get("boot_receipt") or {}
    ctx=_BootContext(_BOOT_MARKER,integrity,payload.get("display_language","ja"),receipt.get("boot_session_id"),receipt.get("setup_session_id"))
    rt=WellStoryRuntime(ctx,root=root)
    if rt.boot_receipt()!=receipt: raise BootError("HOST_SESSION_BOOT_RECEIPT_MISMATCH")
    rt.display_language=payload.get("display_language","ja")
    rt.setup_session=deepcopy(payload.get("setup_session") or rt.setup_session)
    rt._setup_confirmation=deepcopy(payload.get("setup_permit"))
    rt.state=deepcopy(payload.get("state"))
    rt.current_state_hash=payload.get("current_state_hash")
    rt.current_commit_id=payload.get("current_commit_id")
    rt.commit_sequence=payload.get("commit_sequence",0)
    rt.commit_archive=deepcopy(payload.get("commit_archive") or [])
    rt.lineages=deepcopy(payload.get("lineages") or rt.lineages)
    if rt.state is not None:
        rt._validate_state(rt.state)
        if _digest(rt.state)!=rt.current_state_hash: raise BootError("HOST_SESSION_STATE_HASH")
    return rt


if __name__=="__main__":
    rt,envelope=boot_player(ROOT,"ja")
    print(json.dumps(envelope,ensure_ascii=False))
