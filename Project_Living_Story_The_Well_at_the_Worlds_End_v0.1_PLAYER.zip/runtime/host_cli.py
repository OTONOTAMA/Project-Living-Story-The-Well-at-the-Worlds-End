from __future__ import annotations
from pathlib import Path
import argparse, json, sys
from well_story_runtime import restore_host_checkpoint

def read_payload(args):
    if args.payload_file:
        return json.loads(Path(args.payload_file).read_text(encoding='utf-8'))
    if args.payload_json:
        return json.loads(args.payload_json)
    if args.stdin_payload:
        raw=sys.stdin.read()
        return json.loads(raw) if raw.strip() else {}
    return {}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',required=True)
    ap.add_argument('--session',required=True)
    ap.add_argument('--op',required=True,choices=['context','submit-draft','prepare-confirmation','confirm','new-game','status','switch-language','export-save','import-save','commit-effects'])
    ap.add_argument('--payload-json')
    ap.add_argument('--payload-file')
    ap.add_argument('--stdin-payload',action='store_true')
    args=ap.parse_args()
    rt=restore_host_checkpoint(args.session,args.root)
    payload=read_payload(args)
    if args.op=='context':
        out=rt.character_setup_context()
    elif args.op=='submit-draft':
        out=rt.submit_character_draft(
            payload['raw_user_text'],payload['draft_profile'],payload['field_provenance'],payload['classification'],payload.get('open_material_questions',[]))
    elif args.op=='prepare-confirmation':
        out=rt.prepare_final_confirmation()
    elif args.op=='confirm':
        out=rt.accept_final_confirmation(payload['raw_user_text'],payload['interpreted_intent'],payload['challenge_id'],payload.get('divergence_confirmed',False),payload.get('low_agency_confirmed',False))
    elif args.op=='new-game':
        out=rt.new_game(payload['bridge_history'],payload['setup_permit'],payload.get('display_language'))
    elif args.op=='status':
        out=rt.status_view()
    elif args.op=='switch-language':
        out=rt.switch_language(payload['display_language'])
    elif args.op=='export-save':
        out=rt.export_save()
    elif args.op=='import-save':
        out=rt.import_save(payload['save'])
    elif args.op=='commit-effects':
        out=rt.commit_effects(payload['effects'],payload['summary'])
    else:
        raise RuntimeError('UNKNOWN_OP')
    rt.write_host_checkpoint(args.session)
    print(json.dumps(out,ensure_ascii=False))

if __name__=='__main__':
    main()
