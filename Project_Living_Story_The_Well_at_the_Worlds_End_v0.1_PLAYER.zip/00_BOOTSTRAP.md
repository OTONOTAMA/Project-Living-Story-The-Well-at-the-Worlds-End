# Project Living Story — The Well at the World's End
## MACHINE-BOUND PLAYER BOOTSTRAP

This file is a routing contract. **It is not a story prompt.**

### Mandatory boot route

1. Extract/open this PLAYER package in a machine-execution workspace.
2. Execute `BOOT.py` (or call `runtime.well_story_runtime.boot_player()` in a persistent Python session).
3. A valid boot MUST return a runtime-issued `boot_receipt` whose package/version/fingerprint were calculated from the actual package files.
4. Keep the runtime object alive, or keep the host-session checkpoint written by `BOOT.py` and use `runtime/host_cli.py` for later machine operations.
5. Only after the verified boot may the host display the `startup` text returned by the runtime.

### Fail closed

If machine/file execution is unavailable, package verification fails, or no runtime-issued boot receipt exists, **do not improvise the game, do not reconstruct the startup from package text, and do not simulate a successful runtime**.

Show only the localized runtime-unavailable message from `OPENING_PRESENTATION_CONTRACT.json` and stop.

### Character setup binding

Character setup is a Machine-owned session state machine:

`AWAITING_DESCRIPTION -> CLARIFICATION -> READY_FOR_CONFIRMATION -> AWAITING_FINAL_CONFIRMATION -> CONFIRMED -> GAME_ACTIVE`

The host AI interprets natural language, but it does not own the setup state.

- Submit the user's literal setup text plus the AI interpretation to the runtime.
- Omitted details remain unresolved unless an explicitly authorized operational default applies.
- A bare object label such as `石になる` / `I will be a stone` MUST NOT begin story narration.
- For object/structure-like characters, resolve the material agency/perception/self-movement decisions plus name/address and communication before final confirmation.
- The runtime issues the final-confirmation challenge and records evidence from the later user confirmation turn.
- The runtime then issues a setup permit.
- `new_game()` uses the runtime-stored confirmed profile; the host cannot replace it with a fresh profile at genesis.
- Formal-start narration is allowed only after `new_game()` returns `COMMITTED`.

### Authority boundary

Human: purpose, choices, approval, final judgment.

AI: meaning, interpretation, reasoning, world consequence proposals, natural-language realization.

Machine: package identity, boot/session identity, setup lifecycle, state, validation, commit, SAVE/LOAD, integrity, evidence.

Visible prose never substitutes for a Machine commit.
